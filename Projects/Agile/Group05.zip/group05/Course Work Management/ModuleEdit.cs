﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course_Work_Management
{
    public partial class ModuleEdit : Form
    {
        private ModuleManager m_ModuleManager = null;
        private Assessment m_Assessment = null;
        private List<Assessment> tempList = null;

        public ModuleEdit()
        {
            InitializeComponent();
        }

        public ModuleEdit(ModuleManager pModuleManager): this()
        {
            m_ModuleManager = pModuleManager;
            label1.Text += m_ModuleManager.GetForename + " " + m_ModuleManager.GetSurname;
            tempList = m_ModuleManager.GetAssessmentList;
            RefreshList();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_Assessment = (Assessment)moduleListBox.SelectedItem;
        }

        /// <summary>
        /// Refreshes the list of assessments for the manager
        /// Gets list of modules for each manager, then searches assessment list for matching module codes and adds them to list
        /// </summary>
        public void RefreshList()
        {
            moduleListBox.Items.Clear();
            List<string> codeList = m_ModuleManager.GetModuleCodes;
            for (int i = 0; i< codeList.Count; i++)
            {
                for (int j = 0; j < Program.assessList.Count; j++)
                {
                    if ((codeList[i] == Program.assessList[j].GetModuleCode) && (Program.assessList[j].GetChecked == false))
                    {
                        moduleListBox.Items.Add(Program.assessList[j]);
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(m_Assessment == null)
            {
                MessageBox.Show("Please select an assessment to edit");
            }
            else
            {
                AssessmentElement form = new AssessmentElement(m_ModuleManager, m_Assessment);
                form.Show();
                form.FormClosed += new FormClosedEventHandler(Form_Closed);
            }
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            AssessmentElement form = new AssessmentElement(m_ModuleManager);
            form.Show();
            form.FormClosed += new FormClosedEventHandler(Form_Closed);
        }

        private void Form_Closed(object sender, FormClosedEventArgs e)
        {
            AssessmentElement form = (AssessmentElement)sender;
            RefreshList();
        }

        private void AssessmentElement_FormClosed(object sender, System.EventArgs e)
        {
            RefreshList();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            m_Assessment = (Assessment)moduleListBox.SelectedItem;
            if(m_Assessment == null)
            {
                MessageBox.Show("Please select a module from the list");
            }
            else
            {
                for (int i = 0; i < Program.assessList.Count; i++)
                {
                    if (Program.assessList[i].GetAssessmentCode == m_Assessment.GetAssessmentCode)
                    {
                        MessageBox.Show("Deleted assessment: " + Program.assessList[i].GetAssessmentName + ", " + Program.assessList[i].GetAssessmentCode);
                        Program.assessList.Remove(Program.assessList[i]);
                        break;
                    }
                }
                RefreshList();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            RefreshList();
        }
    }
}
