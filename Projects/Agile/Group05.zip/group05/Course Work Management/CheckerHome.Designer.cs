﻿namespace Course_Work_Management
{
    partial class CheckerHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.assessBox = new System.Windows.Forms.ListBox();
            this.okBut = new System.Windows.Forms.Button();
            this.logUser = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(68, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Assessments ready for checking";
            // 
            // assessBox
            // 
            this.assessBox.FormattingEnabled = true;
            this.assessBox.Location = new System.Drawing.Point(71, 75);
            this.assessBox.Name = "assessBox";
            this.assessBox.Size = new System.Drawing.Size(493, 316);
            this.assessBox.TabIndex = 1;
            this.assessBox.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // okBut
            // 
            this.okBut.Location = new System.Drawing.Point(645, 368);
            this.okBut.Name = "okBut";
            this.okBut.Size = new System.Drawing.Size(75, 23);
            this.okBut.TabIndex = 2;
            this.okBut.Text = "Okay";
            this.okBut.UseVisualStyleBackColor = true;
            this.okBut.Click += new System.EventHandler(this.button1_Click);
            // 
            // logUser
            // 
            this.logUser.AutoSize = true;
            this.logUser.Location = new System.Drawing.Point(68, 19);
            this.logUser.Name = "logUser";
            this.logUser.Size = new System.Drawing.Size(35, 13);
            this.logUser.TabIndex = 3;
            this.logUser.Text = "label2";
            this.logUser.Click += new System.EventHandler(this.logUser_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(645, 339);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Refresh List";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // CheckerHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.logUser);
            this.Controls.Add(this.okBut);
            this.Controls.Add(this.assessBox);
            this.Controls.Add(this.label1);
            this.Name = "CheckerHome";
            this.Text = "CheckerHome";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox assessBox;
        private System.Windows.Forms.Button okBut;
        private System.Windows.Forms.Label logUser;
        private System.Windows.Forms.Button button1;
    }
}