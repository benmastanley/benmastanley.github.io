﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Course_Work_Management
{
    public partial class LoginScreen : Form
    {
        public static Dictionary<string, string> usernamePass = new Dictionary<string, string>();
        public static Dictionary<string, string> usernameType = new Dictionary<string, string>();

        public LoginScreen()
        {
            //GetUserData();
            InitializeComponent();
        }

        string username = null;
        string password = null;
        //Checks loging details against users saved in text files

        private void loginButton_Click(object sender, EventArgs e)
        {
            username = usernameBox.Text.ToString();
            username = username.Trim();
            //username = username.ToLower(); //Dictionary key not lower
            password = passwordBox.Text.ToString();
            bool usernameFound = false;
            bool passwordFound = false;
            for(int i = 0; i < Program.managersList.Count; i++)
            {
                if(Program.managersList[i].GetUsername == username)
                {
                    usernameFound = true;
                    if(Program.managersList[i].GetPassword == password)
                    {
                        passwordFound = true;
                        //MessageBox.Show("Login successful"); //Annoying after a while maybe uncomment for final program - it's obvious you logged in though cause it loads
                        Manager_Home ManagerHome = new Manager_Home(Program.managersList[i]);
                        ManagerHome.Show();
                        break;
                    }
                }
            }
            if(passwordFound == false)
            {
                for (int i = 0; i < Program.checkersList.Count; i++)
                {
                    if (Program.checkersList[i].GetUsername == username)
                    {
                        usernameFound = true;
                        if (Program.checkersList[i].GetPassword == password)
                        {
                            passwordFound = true;
                            //MessageBox.Show("Login successful");
                            CheckerHome CheckerHome = new CheckerHome(Program.checkersList[i]);
                            CheckerHome.Show();
                            break;
                        }
                    }
                }
            }
            if(passwordFound == false)
            {
                for (int i = 0; i < Program.PDList.Count; i++)
                {
                    if (Program.PDList[i].GetUsername == username)
                    {
                        usernameFound = true;
                        if (Program.PDList[i].GetPassword == password)
                        {
                            passwordFound = true;
                            MessageBox.Show("Login successful");
                            PDHome PDHOME = new PDHome(Program.PDList[i]);
                            PDHOME.Show();
                            break;
                        }
                    }
                }
            }
            if(passwordFound == false)
            {
                for (int i = 0; i < Program.DoSList.Count; i++)
                {
                    if (Program.DoSList[i].GetUsername == username)
                    {
                        usernameFound = true;
                        if (Program.DoSList[i].GetPassword == password)
                        {
                            passwordFound = true;
                            MessageBox.Show("Login successful");
                            DOSHome DoSHome = new DOSHome(Program.DoSList[i]);
                            DoSHome.Show();
                            break;
                        }
                    }
                }
            }

            if (usernameFound == false)
            {
                MessageBox.Show("Username or password incorrect");
            }
            else if(passwordFound == false)
            {
                MessageBox.Show("Password incorrect");
            }
        }

        //Method for writing details back to the text file
        private void saveDetails()
        {
            StreamWriter file = new StreamWriter("loginDetails.txt");
            for(int i = 0; i < usernameType.Count; i++)
            {
                var item = usernamePass.ElementAt(i);
                var tempUsername = item.Key;
                var tempPassword = item.Value;
                var item2 = usernameType.ElementAt(i);
                var tempUserType = item2.Value;
                file.WriteLine("{0} {1} {2}", tempUsername, tempPassword, tempUserType);
            }

            //using (StreamWriter file = new StreamWriter("loginRoles.txt"))
            //    foreach (var entry in usernameType)
            //        file.WriteLine("{0} {1}", entry.Key, entry.Value);
        }
    }
}
