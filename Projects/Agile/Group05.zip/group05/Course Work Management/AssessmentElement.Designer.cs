﻿namespace Course_Work_Management
{
    partial class AssessmentElement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ReleaseDate = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SubDate = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.permitExt = new System.Windows.Forms.Label();
            this.feedbackDate = new System.Windows.Forms.Label();
            this.AssessCode = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.AssessName = new System.Windows.Forms.TextBox();
            this.AssessType = new System.Windows.Forms.TextBox();
            this.PercentOfMod = new System.Windows.Forms.TextBox();
            this.ModName = new System.Windows.Forms.TextBox();
            this.NumOfStud = new System.Windows.Forms.TextBox();
            this.OkButton = new System.Windows.Forms.Button();
            this.CancelButton = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.Session = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.checkerCombo = new System.Windows.Forms.ComboBox();
            this.modCodesCombo = new System.Windows.Forms.ComboBox();
            this.newModBut = new System.Windows.Forms.Button();
            this.uploadFileButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ReleaseDate
            // 
            this.ReleaseDate.Location = new System.Drawing.Point(1555, 200);
            this.ReleaseDate.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.ReleaseDate.MaxLength = 10;
            this.ReleaseDate.Name = "ReleaseDate";
            this.ReleaseDate.Size = new System.Drawing.Size(260, 38);
            this.ReleaseDate.TabIndex = 9;
            this.ReleaseDate.TextChanged += new System.EventHandler(this.ReleaseDate_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1547, 162);
            this.label1.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(336, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "Relase Date: dd/mm/yyyy";
            // 
            // SubDate
            // 
            this.SubDate.Location = new System.Drawing.Point(1555, 293);
            this.SubDate.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.SubDate.MaxLength = 10;
            this.SubDate.Name = "SubDate";
            this.SubDate.Size = new System.Drawing.Size(260, 38);
            this.SubDate.TabIndex = 10;
            this.SubDate.TextChanged += new System.EventHandler(this.SubDate_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1547, 255);
            this.label2.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(395, 32);
            this.label2.TabIndex = 3;
            this.label2.Text = "Submission Date: dd/mm/yyyy";
            // 
            // permitExt
            // 
            this.permitExt.AutoSize = true;
            this.permitExt.Location = new System.Drawing.Point(1547, 441);
            this.permitExt.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.permitExt.Name = "permitExt";
            this.permitExt.Size = new System.Drawing.Size(278, 32);
            this.permitExt.TabIndex = 4;
            this.permitExt.Text = "Permitted Extension:";
            this.permitExt.Click += new System.EventHandler(this.label3_Click);
            // 
            // feedbackDate
            // 
            this.feedbackDate.AutoSize = true;
            this.feedbackDate.Location = new System.Drawing.Point(1547, 496);
            this.feedbackDate.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.feedbackDate.Name = "feedbackDate";
            this.feedbackDate.Size = new System.Drawing.Size(215, 32);
            this.feedbackDate.TabIndex = 5;
            this.feedbackDate.Text = "Feedback Date:";
            this.feedbackDate.Click += new System.EventHandler(this.label4_Click);
            // 
            // AssessCode
            // 
            this.AssessCode.Location = new System.Drawing.Point(56, 107);
            this.AssessCode.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.AssessCode.Name = "AssessCode";
            this.AssessCode.Size = new System.Drawing.Size(260, 38);
            this.AssessCode.TabIndex = 1;
            this.AssessCode.TextChanged += new System.EventHandler(this.AssessCode_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(48, 69);
            this.label5.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(252, 32);
            this.label5.TabIndex = 7;
            this.label5.Text = "Assessment Code:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(48, 162);
            this.label6.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(259, 32);
            this.label6.TabIndex = 8;
            this.label6.Text = "Assessment Name:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(48, 255);
            this.label7.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(247, 32);
            this.label7.TabIndex = 9;
            this.label7.Text = "Assessment Type:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(48, 534);
            this.label8.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(301, 32);
            this.label8.TabIndex = 10;
            this.label8.Text = "Percentage of Module:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(48, 441);
            this.label9.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(199, 32);
            this.label9.TabIndex = 11;
            this.label9.Text = "Module Name:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(48, 348);
            this.label10.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(192, 32);
            this.label10.TabIndex = 12;
            this.label10.Text = "Module Code:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(48, 627);
            this.label11.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(371, 32);
            this.label11.TabIndex = 13;
            this.label11.Text = "Number of students/module:";
            // 
            // AssessName
            // 
            this.AssessName.Location = new System.Drawing.Point(56, 200);
            this.AssessName.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.AssessName.Name = "AssessName";
            this.AssessName.Size = new System.Drawing.Size(260, 38);
            this.AssessName.TabIndex = 2;
            this.AssessName.TextChanged += new System.EventHandler(this.AssessName_TextChanged);
            // 
            // AssessType
            // 
            this.AssessType.Location = new System.Drawing.Point(56, 293);
            this.AssessType.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.AssessType.Name = "AssessType";
            this.AssessType.Size = new System.Drawing.Size(260, 38);
            this.AssessType.TabIndex = 3;
            this.AssessType.TextChanged += new System.EventHandler(this.AssessType_TextChanged);
            // 
            // PercentOfMod
            // 
            this.PercentOfMod.Location = new System.Drawing.Point(56, 572);
            this.PercentOfMod.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.PercentOfMod.MaxLength = 3;
            this.PercentOfMod.Name = "PercentOfMod";
            this.PercentOfMod.Size = new System.Drawing.Size(260, 38);
            this.PercentOfMod.TabIndex = 6;
            this.PercentOfMod.TextChanged += new System.EventHandler(this.PercentOfMod_TextChanged);
            // 
            // ModName
            // 
            this.ModName.Location = new System.Drawing.Point(56, 479);
            this.ModName.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.ModName.Name = "ModName";
            this.ModName.Size = new System.Drawing.Size(260, 38);
            this.ModName.TabIndex = 4;
            this.ModName.TextChanged += new System.EventHandler(this.ModName_TextChanged);
            // 
            // NumOfStud
            // 
            this.NumOfStud.Location = new System.Drawing.Point(56, 665);
            this.NumOfStud.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.NumOfStud.Name = "NumOfStud";
            this.NumOfStud.Size = new System.Drawing.Size(260, 38);
            this.NumOfStud.TabIndex = 7;
            this.NumOfStud.TextChanged += new System.EventHandler(this.NumOfStud_TextChanged);
            // 
            // OkButton
            // 
            this.OkButton.Location = new System.Drawing.Point(1555, 947);
            this.OkButton.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.OkButton.Name = "OkButton";
            this.OkButton.Size = new System.Drawing.Size(200, 55);
            this.OkButton.TabIndex = 20;
            this.OkButton.Text = "OK";
            this.OkButton.UseVisualStyleBackColor = true;
            this.OkButton.Click += new System.EventHandler(this.OkButton_Click);
            // 
            // CancelButton
            // 
            this.CancelButton.Location = new System.Drawing.Point(1816, 947);
            this.CancelButton.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(200, 55);
            this.CancelButton.TabIndex = 21;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1547, 69);
            this.label12.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(299, 32);
            this.label12.TabIndex = 22;
            this.label12.Text = "Session: yy/yy (S1/S2)";
            // 
            // Session
            // 
            this.Session.Location = new System.Drawing.Point(1555, 107);
            this.Session.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.Session.MaxLength = 7;
            this.Session.Name = "Session";
            this.Session.Size = new System.Drawing.Size(260, 38);
            this.Session.TabIndex = 8;
            this.Session.TextChanged += new System.EventHandler(this.Session_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(1547, 386);
            this.label13.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(231, 32);
            this.label13.TabIndex = 24;
            this.label13.Text = "Generated Dates";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1547, 625);
            this.label3.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(289, 32);
            this.label3.TabIndex = 25;
            this.label3.Text = "Assessment Checker:";
            // 
            // checkerCombo
            // 
            this.checkerCombo.FormattingEnabled = true;
            this.checkerCombo.Location = new System.Drawing.Point(1555, 663);
            this.checkerCombo.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.checkerCombo.Name = "checkerCombo";
            this.checkerCombo.Size = new System.Drawing.Size(316, 39);
            this.checkerCombo.TabIndex = 26;
            this.checkerCombo.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // modCodesCombo
            // 
            this.modCodesCombo.FormattingEnabled = true;
            this.modCodesCombo.Location = new System.Drawing.Point(56, 386);
            this.modCodesCombo.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.modCodesCombo.Name = "modCodesCombo";
            this.modCodesCombo.Size = new System.Drawing.Size(316, 39);
            this.modCodesCombo.TabIndex = 27;
            this.modCodesCombo.SelectedIndexChanged += new System.EventHandler(this.modCodesCombo_SelectedIndexChanged);
            // 
            // newModBut
            // 
            this.newModBut.Location = new System.Drawing.Point(395, 386);
            this.newModBut.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.newModBut.Name = "newModBut";
            this.newModBut.Size = new System.Drawing.Size(200, 55);
            this.newModBut.TabIndex = 28;
            this.newModBut.Text = "New Module";
            this.newModBut.UseVisualStyleBackColor = true;
            this.newModBut.Click += new System.EventHandler(this.button1_Click);
            // 
            // uploadFileButton
            // 
            this.uploadFileButton.Location = new System.Drawing.Point(56, 845);
            this.uploadFileButton.Name = "uploadFileButton";
            this.uploadFileButton.Size = new System.Drawing.Size(299, 49);
            this.uploadFileButton.TabIndex = 29;
            this.uploadFileButton.Text = "Upload File";
            this.uploadFileButton.UseVisualStyleBackColor = true;
            this.uploadFileButton.Click += new System.EventHandler(this.uploadFileButton_Click);
            // 
            // AssessmentElement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(2120, 1059);
            this.Controls.Add(this.uploadFileButton);
            this.Controls.Add(this.newModBut);
            this.Controls.Add(this.modCodesCombo);
            this.Controls.Add(this.checkerCombo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.Session);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.OkButton);
            this.Controls.Add(this.NumOfStud);
            this.Controls.Add(this.ModName);
            this.Controls.Add(this.PercentOfMod);
            this.Controls.Add(this.AssessType);
            this.Controls.Add(this.AssessName);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.AssessCode);
            this.Controls.Add(this.feedbackDate);
            this.Controls.Add(this.permitExt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.SubDate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ReleaseDate);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.Name = "AssessmentElement";
            this.Text = "AssessmentElement";
            this.Load += new System.EventHandler(this.AssessmentElement_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ReleaseDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox SubDate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label permitExt;
        private System.Windows.Forms.Label feedbackDate;
        private System.Windows.Forms.TextBox AssessCode;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox AssessName;
        private System.Windows.Forms.TextBox AssessType;
        private System.Windows.Forms.TextBox PercentOfMod;
        private System.Windows.Forms.TextBox ModName;
        private System.Windows.Forms.TextBox NumOfStud;
        private System.Windows.Forms.Button OkButton;
        private System.Windows.Forms.Button CancelButton;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox Session;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox checkerCombo;
        private System.Windows.Forms.ComboBox modCodesCombo;
        private System.Windows.Forms.Button newModBut;
        private System.Windows.Forms.Button uploadFileButton;
    }
}