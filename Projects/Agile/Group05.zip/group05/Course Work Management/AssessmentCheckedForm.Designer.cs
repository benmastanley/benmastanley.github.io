﻿namespace Course_Work_Management
{
    partial class AssessmentCheckedForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.approvedStatus = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.commentsText = new System.Windows.Forms.TextBox();
            this.Q7Label = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Q12Label = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Q11Label = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Q10Label = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Q9Label = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Q8Label = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Q6Label = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Q5Label = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Q4Label = new System.Windows.Forms.Label();
            this.modMarkText = new System.Windows.Forms.TextBox();
            this.Q3Label = new System.Windows.Forms.Label();
            this.intRevText = new System.Windows.Forms.TextBox();
            this.Q2Label = new System.Windows.Forms.Label();
            this.assessSetterText = new System.Windows.Forms.TextBox();
            this.Q1Label = new System.Windows.Forms.Label();
            this.assessCodeText = new System.Windows.Forms.TextBox();
            this.assessTitleText = new System.Windows.Forms.TextBox();
            this.modNameText = new System.Windows.Forms.TextBox();
            this.modLevelText = new System.Windows.Forms.TextBox();
            this.modNumText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.submitButton = new System.Windows.Forms.Button();
            this.backButton = new System.Windows.Forms.Button();
            this.nextButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ammendments = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.approvedStatus);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.commentsText);
            this.panel1.Controls.Add(this.Q7Label);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.Q12Label);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.Q11Label);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.Q10Label);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.Q9Label);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.Q8Label);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.Q6Label);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.Q5Label);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.Q4Label);
            this.panel1.Controls.Add(this.modMarkText);
            this.panel1.Controls.Add(this.Q3Label);
            this.panel1.Controls.Add(this.intRevText);
            this.panel1.Controls.Add(this.Q2Label);
            this.panel1.Controls.Add(this.assessSetterText);
            this.panel1.Controls.Add(this.Q1Label);
            this.panel1.Controls.Add(this.assessCodeText);
            this.panel1.Controls.Add(this.assessTitleText);
            this.panel1.Controls.Add(this.modNameText);
            this.panel1.Controls.Add(this.modLevelText);
            this.panel1.Controls.Add(this.modNumText);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(854, 647);
            this.panel1.TabIndex = 1;
            // 
            // approvedStatus
            // 
            this.approvedStatus.Location = new System.Drawing.Point(137, 609);
            this.approvedStatus.Name = "approvedStatus";
            this.approvedStatus.Size = new System.Drawing.Size(163, 20);
            this.approvedStatus.TabIndex = 82;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(42, 612);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(89, 13);
            this.label11.TabIndex = 81;
            this.label11.Text = "Approved Status:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(42, 381);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 13);
            this.label10.TabIndex = 80;
            this.label10.Text = "Comments:";
            // 
            // commentsText
            // 
            this.commentsText.Location = new System.Drawing.Point(45, 397);
            this.commentsText.Multiline = true;
            this.commentsText.Name = "commentsText";
            this.commentsText.Size = new System.Drawing.Size(768, 206);
            this.commentsText.TabIndex = 79;
            // 
            // Q7Label
            // 
            this.Q7Label.AutoSize = true;
            this.Q7Label.Location = new System.Drawing.Point(42, 292);
            this.Q7Label.Name = "Q7Label";
            this.Q7Label.Size = new System.Drawing.Size(423, 13);
            this.Q7Label.TabIndex = 78;
            this.Q7Label.Text = "Q7. Is the marking scheme consistent with the University’s Generic Grading Descri" +
    "ptors?";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(42, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Page 1/2";
            // 
            // Q12Label
            // 
            this.Q12Label.AutoSize = true;
            this.Q12Label.Location = new System.Drawing.Point(42, 357);
            this.Q12Label.Name = "Q12Label";
            this.Q12Label.Size = new System.Drawing.Size(342, 13);
            this.Q12Label.TabIndex = 77;
            this.Q12Label.Text = "Q12. Is the reassessment method the same as the original assessment?";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(42, 188);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(222, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Assessment Weighting towards Module Mark:";
            // 
            // Q11Label
            // 
            this.Q11Label.AutoSize = true;
            this.Q11Label.Location = new System.Drawing.Point(42, 344);
            this.Q11Label.Name = "Q11Label";
            this.Q11Label.Size = new System.Drawing.Size(343, 13);
            this.Q11Label.TabIndex = 76;
            this.Q11Label.Text = "Q11. If relevant, has a risk assessment been completed and approved?";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(42, 162);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Internal Reviewers:";
            // 
            // Q10Label
            // 
            this.Q10Label.AutoSize = true;
            this.Q10Label.Location = new System.Drawing.Point(42, 331);
            this.Q10Label.Name = "Q10Label";
            this.Q10Label.Size = new System.Drawing.Size(296, 13);
            this.Q10Label.TabIndex = 75;
            this.Q10Label.Text = "Q10. If relevant, does the assessment have ethical approval?";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(42, 136);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Assessment Setter:";
            // 
            // Q9Label
            // 
            this.Q9Label.AutoSize = true;
            this.Q9Label.Location = new System.Drawing.Point(42, 318);
            this.Q9Label.Name = "Q9Label";
            this.Q9Label.Size = new System.Drawing.Size(378, 13);
            this.Q9Label.TabIndex = 73;
            this.Q9Label.Text = "Q9. Does the task require second marking and has the marker been identified?";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(42, 110);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Assessment Code:";
            // 
            // Q8Label
            // 
            this.Q8Label.AutoSize = true;
            this.Q8Label.Location = new System.Drawing.Point(42, 305);
            this.Q8Label.Name = "Q8Label";
            this.Q8Label.Size = new System.Drawing.Size(538, 13);
            this.Q8Label.TabIndex = 72;
            this.Q8Label.Text = "Q8. Is the assessment devised in such a way to limit academic misconduct and prom" +
    "ote assessment for learning?";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(42, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Title of Assessment:";
            // 
            // Q6Label
            // 
            this.Q6Label.AutoSize = true;
            this.Q6Label.Location = new System.Drawing.Point(42, 279);
            this.Q6Label.Name = "Q6Label";
            this.Q6Label.Size = new System.Drawing.Size(369, 13);
            this.Q6Label.TabIndex = 71;
            this.Q6Label.Text = "Q6. Does the marking scheme/assessment criteria appear to be appropriate?";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Module Name:";
            // 
            // Q5Label
            // 
            this.Q5Label.AutoSize = true;
            this.Q5Label.Location = new System.Drawing.Point(42, 266);
            this.Q5Label.Name = "Q5Label";
            this.Q5Label.Size = new System.Drawing.Size(423, 13);
            this.Q5Label.TabIndex = 70;
            this.Q5Label.Text = "Q5. Does the time allocated to the students to complete the task/paper appear sui" +
    "table?";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(524, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Module Level:";
            // 
            // Q4Label
            // 
            this.Q4Label.AutoSize = true;
            this.Q4Label.Location = new System.Drawing.Point(42, 253);
            this.Q4Label.Name = "Q4Label";
            this.Q4Label.Size = new System.Drawing.Size(385, 13);
            this.Q4Label.TabIndex = 69;
            this.Q4Label.Text = "Q4. Does the assessment appear to be at an appropriate level within the FHEQ?";
            // 
            // modMarkText
            // 
            this.modMarkText.Location = new System.Drawing.Point(269, 181);
            this.modMarkText.Name = "modMarkText";
            this.modMarkText.Size = new System.Drawing.Size(567, 20);
            this.modMarkText.TabIndex = 8;
            // 
            // Q3Label
            // 
            this.Q3Label.AutoSize = true;
            this.Q3Label.Location = new System.Drawing.Point(42, 240);
            this.Q3Label.Name = "Q3Label";
            this.Q3Label.Size = new System.Drawing.Size(230, 13);
            this.Q3Label.TabIndex = 68;
            this.Q3Label.Text = "Q3. Is the assessment clear and unambiguous?";
            // 
            // intRevText
            // 
            this.intRevText.Location = new System.Drawing.Point(269, 155);
            this.intRevText.Name = "intRevText";
            this.intRevText.Size = new System.Drawing.Size(567, 20);
            this.intRevText.TabIndex = 7;
            // 
            // Q2Label
            // 
            this.Q2Label.AutoSize = true;
            this.Q2Label.Location = new System.Drawing.Point(42, 227);
            this.Q2Label.Name = "Q2Label";
            this.Q2Label.Size = new System.Drawing.Size(726, 13);
            this.Q2Label.TabIndex = 67;
            this.Q2Label.Text = "Q2. Does the assessment address the relevant learning outcomes stated in the modu" +
    "le specification? If appropriate, are the learning outcomes identified?";
            this.Q2Label.Click += new System.EventHandler(this.Q2Label_Click);
            // 
            // assessSetterText
            // 
            this.assessSetterText.Location = new System.Drawing.Point(269, 129);
            this.assessSetterText.Name = "assessSetterText";
            this.assessSetterText.Size = new System.Drawing.Size(567, 20);
            this.assessSetterText.TabIndex = 6;
            // 
            // Q1Label
            // 
            this.Q1Label.AutoSize = true;
            this.Q1Label.Location = new System.Drawing.Point(42, 214);
            this.Q1Label.Name = "Q1Label";
            this.Q1Label.Size = new System.Drawing.Size(565, 13);
            this.Q1Label.TabIndex = 66;
            this.Q1Label.Text = "Q1. Does the assessment match the weighting and size/length as published in the m" +
    "odule specification and CANVAS?";
            this.Q1Label.Click += new System.EventHandler(this.label18_Click);
            // 
            // assessCodeText
            // 
            this.assessCodeText.Location = new System.Drawing.Point(269, 103);
            this.assessCodeText.Name = "assessCodeText";
            this.assessCodeText.Size = new System.Drawing.Size(567, 20);
            this.assessCodeText.TabIndex = 5;
            // 
            // assessTitleText
            // 
            this.assessTitleText.Location = new System.Drawing.Point(269, 77);
            this.assessTitleText.Name = "assessTitleText";
            this.assessTitleText.Size = new System.Drawing.Size(567, 20);
            this.assessTitleText.TabIndex = 4;
            // 
            // modNameText
            // 
            this.modNameText.Location = new System.Drawing.Point(269, 51);
            this.modNameText.Name = "modNameText";
            this.modNameText.Size = new System.Drawing.Size(567, 20);
            this.modNameText.TabIndex = 3;
            // 
            // modLevelText
            // 
            this.modLevelText.Location = new System.Drawing.Point(604, 25);
            this.modLevelText.Name = "modLevelText";
            this.modLevelText.Size = new System.Drawing.Size(232, 20);
            this.modLevelText.TabIndex = 2;
            // 
            // modNumText
            // 
            this.modNumText.Location = new System.Drawing.Point(269, 25);
            this.modNumText.Name = "modNumText";
            this.modNumText.Size = new System.Drawing.Size(196, 20);
            this.modNumText.TabIndex = 1;
            this.modNumText.TextChanged += new System.EventHandler(this.modNumText_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Module Number:";
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(961, 634);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(75, 23);
            this.submitButton.TabIndex = 65;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // backButton
            // 
            this.backButton.Location = new System.Drawing.Point(880, 634);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(75, 23);
            this.backButton.TabIndex = 64;
            this.backButton.Text = "Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click_1);
            // 
            // nextButton
            // 
            this.nextButton.Location = new System.Drawing.Point(961, 634);
            this.nextButton.Name = "nextButton";
            this.nextButton.Size = new System.Drawing.Size(75, 23);
            this.nextButton.TabIndex = 63;
            this.nextButton.Text = "Next";
            this.nextButton.UseVisualStyleBackColor = true;
            this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Location = new System.Drawing.Point(880, 634);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(75, 23);
            this.closeButton.TabIndex = 62;
            this.closeButton.Text = "Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.ammendments);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(854, 647);
            this.panel2.TabIndex = 83;
            // 
            // ammendments
            // 
            this.ammendments.Location = new System.Drawing.Point(57, 78);
            this.ammendments.Multiline = true;
            this.ammendments.Name = "ammendments";
            this.ammendments.Size = new System.Drawing.Size(756, 337);
            this.ammendments.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(54, 62);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(644, 13);
            this.label13.TabIndex = 17;
            this.label13.Text = "Assessment setters response to the External\'s comments. (Please explain what acti" +
    "on has been taken or why action hasn\'t been taken.)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(42, 19);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(52, 13);
            this.label12.TabIndex = 16;
            this.label12.Text = "Page 2/2";
            // 
            // AssessmentCheckedForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1054, 669);
            this.Controls.Add(this.nextButton);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "AssessmentCheckedForm";
            this.Text = "AssessmentCheckedForm";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox modMarkText;
        private System.Windows.Forms.TextBox intRevText;
        private System.Windows.Forms.TextBox assessSetterText;
        private System.Windows.Forms.TextBox assessCodeText;
        private System.Windows.Forms.TextBox assessTitleText;
        private System.Windows.Forms.TextBox modNameText;
        private System.Windows.Forms.TextBox modLevelText;
        private System.Windows.Forms.TextBox modNumText;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.Button nextButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Label Q7Label;
        private System.Windows.Forms.Label Q12Label;
        private System.Windows.Forms.Label Q11Label;
        private System.Windows.Forms.Label Q10Label;
        private System.Windows.Forms.Label Q9Label;
        private System.Windows.Forms.Label Q8Label;
        private System.Windows.Forms.Label Q6Label;
        private System.Windows.Forms.Label Q5Label;
        private System.Windows.Forms.Label Q4Label;
        private System.Windows.Forms.Label Q3Label;
        private System.Windows.Forms.Label Q2Label;
        private System.Windows.Forms.Label Q1Label;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox commentsText;
        private System.Windows.Forms.TextBox approvedStatus;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox ammendments;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
    }
}