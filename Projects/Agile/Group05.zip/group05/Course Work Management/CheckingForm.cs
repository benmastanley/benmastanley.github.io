﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course_Work_Management
{
    public partial class CheckingForm : Form
    {
        private Assessment m_Assessment = null;
        private ModuleChecker m_ModuleChecker = null;
        private ModuleManager m_Manager = null;
        private CheckedAssessment m_Checked = null;
        List<Panel> listPanel = new List<Panel>();
        int index = 0;
        DateTime ApprovalDate = DateTime.Now;
        int m_Q1;
        int m_Q2;
        int m_Q3;
        int m_Q4;
        int m_Q5;
        int m_Q6;
        int m_Q7;
        int m_Q8;
        int m_Q9;
        int m_Q10;
        int m_Q11;
        int m_Q12;
        int m_Approved;
        bool m_AmmendNeeded = false;
        bool checkedAmmend = false;


        public CheckingForm()
        {
            InitializeComponent();
            label17.Text = "Q2. Does the assessment address the relevant learning outcomes stated in the module specification? If appropriate, are the learning\noutcomes identified?";
            dateLabel.Text = "Date: " + ApprovalDate.ToString("dd/MM/yyyy");
        }

        public CheckingForm(Assessment pAssessment, ModuleChecker pChecker) : this()
        {
            m_Assessment = pAssessment;
            m_ModuleChecker = pChecker;
            backButton.Visible = false;
            LoadData();
        }

        private void LoadData()
        {
            modNumText.Text = m_Assessment.GetModuleCode;
            modLevelText.Text = "N/A";
            modNameText.Text = m_Assessment.GetModuleName;
            assessTitleText.Text = m_Assessment.GetAssessmentName;
            assessCodeText.Text = m_Assessment.GetAssessmentCode;
            for(int i = 0; i < Program.managersList.Count; i++)
            {
                List<Module> tempList = Program.managersList[i].GetManagersModules;
                for(int j = 0; j < tempList.Count; j++)
                {
                    if (m_Assessment.GetModuleCode == tempList[j].GetModuleCode)
                    {
                        m_Manager = Program.managersList[i];
                        assessSetterText.Text = m_Manager.GetForename + " " + m_Manager.GetSurname;
                        break;
                    }
                }
            }
            intRevText.Text = m_ModuleChecker.GetForename + " " + m_ModuleChecker.GetSurname;
            modMarkText.Text = m_Assessment.GetPercentageGrade.ToString();
            modNumText.ReadOnly = true;
            modLevelText.ReadOnly = true;
            modNameText.ReadOnly = true;
            assessTitleText.ReadOnly = true;
            assessCodeText.ReadOnly = true;
            assessSetterText.ReadOnly = true;
            intRevText.ReadOnly = true;
            modMarkText.ReadOnly = true;
            filePathText.Text = m_Assessment.GetFilePath;
            filePathText.ReadOnly = true;
        }

        #region Panels
        private void CheckingForm_Load(object sender, EventArgs e)
        {
            listPanel.Add(panel1);
            listPanel.Add(panel2);
            listPanel.Add(panel3);
            listPanel[index].BringToFront();
            nextButton.Visible = true;
            submitButton.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(index<listPanel.Count - 1)
            {
                index++;
                listPanel[index].BringToFront();
            }
            if(index > 0)
            {
                closeButton.Visible = false;
                backButton.Visible = true;
            }
            if(index > 1)
            {
                nextButton.Visible = false;
                submitButton.Visible = true;
            }
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            if (index > 0)
            {
                index--;
                listPanel[index].BringToFront();
            }
            if(index == 0)
            {
                backButton.Visible = false;
                closeButton.Visible = true;
            }
            if(index < 2)
            {
                submitButton.Visible = false;
                nextButton.Visible = true;
            }
        }
        #endregion
        
        private bool checkValues()
        {
            string error = "";
            string m_AssessmentSetter = assessSetterText.Text;
            string m_InternalReviewer = intRevText.Text;
            List<int> answers = new List<int>();
            if(m_Q1 == 0 || m_Q2 == 0 || m_Q3 == 0 || m_Q4 == 0 || m_Q5 == 0 || m_Q6 == 0 || m_Q7 == 0 || m_Q8 == 0 || m_Q9 == 0 || m_Q10 == 0 || m_Q11 == 0 || m_Q12 == 0)
            {
                error += "Questions 1-12 have to be answered\n";
            }
            else
            {
                answers.Add(m_Q1);
                answers.Add(m_Q2);
                answers.Add(m_Q3);
                answers.Add(m_Q4);
                answers.Add(m_Q5);
                answers.Add(m_Q6);
                answers.Add(m_Q7);
                answers.Add(m_Q8);
                answers.Add(m_Q9);
                answers.Add(m_Q10);
                answers.Add(m_Q11);
                answers.Add(m_Q12);
            }
            string m_Comments = commentsText.Text;
            if (m_Comments == "")
            {
                error += "Please provide details for any 'No' responses Q1-12 and provide an overall evaluation of the assessment\n";
            }
            if (m_Comments.Contains('*'))
            {
                error += "Comments cannot contain the illegal character '*'\n";
            }

            if(m_Approved == 0)
            {
                error += "Please select approved status\n";
            }

            DateTime m_ApprovedDate = ApprovalDate;

            if(checkedAmmend == false)
            {
                error += "Please answer question 13\n";
            }
            
            if(error == "")
            {
                m_Checked = new CheckedAssessment(m_Assessment.GetAssessmentCode, m_Assessment.GetAssessmentName, m_Assessment.GetAssessmentType, m_Assessment.GetModuleName, m_Assessment.GetModuleCode, m_Assessment.GetPercentageGrade, m_Assessment.GetNumOfStudents, m_Assessment.GetSession,
                    m_Assessment.GetReleaseDate, m_Assessment.GetSubmissionDate, m_Assessment.GetExtensionDate, m_Assessment.GetFeedbackDate, true, m_Assessment.GetFilePath,
                    m_AssessmentSetter, m_InternalReviewer, answers, m_Comments, m_Approved, m_ApprovedDate, m_AmmendNeeded, ""); //generated by this form
                return true;
            }
            else
            {
                MessageBox.Show(error);
                return false;
            }
        }

        //Sets assessment checked to true
        private void submitButton_Click(object sender, EventArgs e)
        {
            if(checkValues() == true)
            {
                for (int i = 0; i < Program.assessList.Count; i++)
                {
                    if (Program.assessList[i].GetAssessmentCode == m_Assessment.GetAssessmentCode)
                    {
                        Program.assessList[i].SetChecked(true);
                    }
                }
                m_ModuleChecker.MoveListItem(m_Assessment.GetAssessmentCode);
                m_Manager.AddToCheckedList(m_Checked);
                Program.checkedAssessList.Add(m_Checked);
                this.Close();
            }
        }

        #region Change radio button values
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            m_Q1 = 1;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            m_Q1 = 2;
        }
        
        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            m_Q1 = 3;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            m_Q2 = 1;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            m_Q2 = 2;
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            m_Q2 = 3;
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            m_Q3 = 1;
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            m_Q3 = 2;
        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            m_Q3 = 3;
        }

        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {
            m_Q4 = 1;
        }

        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {
            m_Q4 = 2;
        }

        private void radioButton12_CheckedChanged(object sender, EventArgs e)
        {
            m_Q4 = 3;
        }

        private void radioButton13_CheckedChanged(object sender, EventArgs e)
        {
            m_Q5 = 1;
        }

        private void radioButton14_CheckedChanged(object sender, EventArgs e)
        {
            m_Q5 = 2;
        }

        private void radioButton15_CheckedChanged(object sender, EventArgs e)
        {
            m_Q5 = 3;
        }

        private void radioButton16_CheckedChanged(object sender, EventArgs e)
        {
            m_Q6 = 1;
        }

        private void radioButton17_CheckedChanged(object sender, EventArgs e)
        {
            m_Q6 = 2;
        }

        private void radioButton18_CheckedChanged(object sender, EventArgs e)
        {
            m_Q6 = 3;
        }

        private void radioButton19_CheckedChanged(object sender, EventArgs e)
        {
            m_Q7 = 1;
        }

        private void radioButton20_CheckedChanged(object sender, EventArgs e)
        {
            m_Q7 = 2;
        }

        private void radioButton21_CheckedChanged(object sender, EventArgs e)
        {
            m_Q7 = 3;
        }

        private void radioButton22_CheckedChanged(object sender, EventArgs e)
        {
            m_Q8 = 1;
        }

        private void radioButton23_CheckedChanged(object sender, EventArgs e)
        {
            m_Q8 = 2;
        }

        private void radioButton24_CheckedChanged(object sender, EventArgs e)
        {
            m_Q8 = 3;
        }

        private void radioButton25_CheckedChanged(object sender, EventArgs e)
        {
            m_Q9 = 1;
        }

        private void radioButton26_CheckedChanged(object sender, EventArgs e)
        {
            m_Q9 = 2;
        }

        private void radioButton27_CheckedChanged(object sender, EventArgs e)
        {
            m_Q9 = 3;
        }

        private void radioButton28_CheckedChanged(object sender, EventArgs e)
        {
            m_Q10 = 1;
        }

        private void radioButton29_CheckedChanged(object sender, EventArgs e)
        {
            m_Q10 = 2;
        }

        private void radioButton30_CheckedChanged(object sender, EventArgs e)
        {
            m_Q10 = 3;
        }

        private void radioButton31_CheckedChanged(object sender, EventArgs e)
        {
            m_Q11 = 1;
        }

        private void radioButton32_CheckedChanged(object sender, EventArgs e)
        {
            m_Q11 = 2;
        }

        private void radioButton33_CheckedChanged(object sender, EventArgs e)
        {
            m_Q11 = 3;
        }

        private void radioButton34_CheckedChanged(object sender, EventArgs e)
        {
            m_Q12 = 1;
        }

        private void radioButton35_CheckedChanged(object sender, EventArgs e)
        {
            m_Q12 = 2;
        }

        private void radioButton36_CheckedChanged(object sender, EventArgs e)
        {
            m_Q12 = 3;
        }

        private void radioButton37_CheckedChanged(object sender, EventArgs e)
        {
            m_Approved = 1;
        }

        private void radioButton38_CheckedChanged(object sender, EventArgs e)
        {
            m_Approved = 2;
        }

        private void radioButton39_CheckedChanged(object sender, EventArgs e)
        {
            m_Approved = 3;
        }

        private void radioButton40_CheckedChanged(object sender, EventArgs e)
        {
            m_AmmendNeeded = true;
            checkedAmmend = true;
        }

        private void radioButton41_CheckedChanged(object sender, EventArgs e)
        {
            m_AmmendNeeded = false;
            checkedAmmend = true;
        }
#endregion

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void modNumText_TextChanged(object sender, EventArgs e)
        {

        }

        private void yesLabel_Click(object sender, EventArgs e)
        {

        }

        private void intRevText_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
