﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course_Work_Management
{
    public partial class CreateModule : Form
    {
        private Module m_Module = null;
        private ModuleManager m_Manager = null;
        private Faculty m_Faculty = null;

        public CreateModule()
        {
            InitializeComponent();
            RefreshManagers();
            LoadFaculties();
        }

        private void RefreshManagers()
        {
            modManCombo.Items.Clear();
            for(int i = 0; i< Program.managersList.Count; i++)
            {
                modManCombo.Items.Add(Program.managersList[i]);
            }
        }

        private void LoadFaculties()
        {
            for (int i = 0; i < Program.facultyList.Count; i++)
            {
                facultyCombo.Items.Add(Program.facultyList[i]);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string error = "";
            string modCode = "";
            int numStu = 0;
            string name = "";

            string modName = modNameText.Text;
            if(modName == "")
            {
                error += "Module name cannot be blank\n";
            }
            if(modCodeText.Text == "")
            {
                error += "Module code cannot blank\n";
            }
            else
            {
                try
                {
                    int temp = int.Parse(modCodeText.Text);
                    modCode = temp.ToString();
                }
                catch
                {
                    error += "Module code may only contain numbers\n";
                }
            }

            for(int i = 0; i < Program.moduleList.Count; i++)
            {
                if(Program.moduleList[i].GetModuleCode == modCode)
                {
                    error += "Module code already exists\n";
                }
            }
            if (numOfStudText.Text == "")
            {
                error += "Number of students must be 0 or greater\n";
            }
            else
            {
                try
                {
                    numStu = int.Parse(numOfStudText.Text);
                }
                catch
                {
                    error += "Number of students may only contain numbers\n";
                }
            }

            if(m_Manager == null)
            {
                error += "Please select a module manager from the list box\n";
            }
            else
            {
                name = m_Manager.GetForename + " " + m_Manager.GetSurname;
            }
            if (m_Faculty == null)
            {
                error += "Please select a faculty from the list\n";
            }
            if (error == "")
            {
                m_Manager.AddToCodesList(modCode);
                Program.moduleList.Add(new Module(modName, modCode, numStu, name, m_Faculty.GetFacultyName));
                MessageBox.Show("New module created: " + modCode + "\r\n" + modName);
                this.Close();
            }
            else
            {
                MessageBox.Show(error);
            }
        }

        private void facultyCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_Faculty = (Faculty)facultyCombo.SelectedItem;
        }

        private void modManCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_Manager = (ModuleManager)modManCombo.SelectedItem;
        }

        private void cancelBut_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void modCodeText_TextChanged(object sender, EventArgs e)
        {

        }

        private void numOfStudText_TextChanged(object sender, EventArgs e)
        {

        }


        private void CreateModule_Load(object sender, EventArgs e)
        {

        }

        private void modNameText_TextChanged(object sender, EventArgs e)
        {

        }


    }
}
