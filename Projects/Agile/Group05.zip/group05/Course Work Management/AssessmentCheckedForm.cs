﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course_Work_Management
{
    public partial class AssessmentCheckedForm : Form
    {

        private CheckedAssessment m_Assessment = null;
        List<Panel> listPanel = new List<Panel>();
        int index = 0;

        public AssessmentCheckedForm()
        {
            InitializeComponent();
        }

        public AssessmentCheckedForm(CheckedAssessment pAssessment) : this()
        {
            m_Assessment = pAssessment;
            AddData();
            AddPanels();
        }

        private void AddData()
        {
            List<string> wordList = new List<string>();
            List<int> tempList = m_Assessment.GetIntList;
            for (int i = 0; i < tempList.Count; i++)
            {
                GetWord(tempList[i], out string word);
                wordList.Add(word);
            }

            //Q1Label.Text = "Q1. Does the assessment match the weighting and size/length as published in the module specification and CANVAS?";
            Q1Label.Text += " " + wordList[0];
            Q2Label.Text += " " + wordList[1];
            Q3Label.Text += " " + wordList[2];
            Q4Label.Text += " " + wordList[3];
            Q5Label.Text += " " + wordList[4];
            Q6Label.Text += " " + wordList[5];
            Q7Label.Text += " " + wordList[6];
            Q8Label.Text += " " + wordList[7];
            Q9Label.Text += " " + wordList[8];
            Q10Label.Text += " " + wordList[9];
            Q11Label.Text += " " + wordList[10];
            Q12Label.Text += " " + wordList[11];
            modNumText.Text = m_Assessment.GetModuleCode;
            modNumText.ReadOnly = true;
            modLevelText.Text = "N/A";
            modLevelText.ReadOnly = true;
            modNameText.Text = m_Assessment.GetModuleName;
            modNameText.ReadOnly = true;
            assessTitleText.Text = m_Assessment.GetAssessmentName;
            assessTitleText.ReadOnly = true;
            assessCodeText.Text = m_Assessment.GetAssessmentCode;
            assessCodeText.ReadOnly = true;
            assessSetterText.Text = m_Assessment.GetSetterName;
            assessSetterText.ReadOnly = true;
            intRevText.Text = m_Assessment.GetInternalReviewer;
            intRevText.ReadOnly = true;
            modMarkText.Text = m_Assessment.GetPercentageGrade.ToString();
            modMarkText.ReadOnly = true;
            commentsText.Text = m_Assessment.GetComments;
            commentsText.ReadOnly = true;
            int temp = m_Assessment.GetApprovedStatus;
            switch (temp)
            {
                case 1:
                    approvedStatus.Text = "Approved";
                    break;
                case 2:
                    approvedStatus.Text = "Approved with suggested ammendments";
                    break;
                case 3:
                    approvedStatus.Text = "Not Approved";
                    break;
            }
            approvedStatus.ReadOnly = true;
            ammendments.Text = m_Assessment.GetAmmendments;
        }

        private void GetWord(int pValue, out string word)
        {
            word = "";
            switch(pValue){
                case 1:
                    word = "Yes";
                    break;
                case 2:
                    word = "No";
                    break;
                case 3:
                    word = "N/A";
                    break;
            }
            return;
        }

        #region Panels
        //private void AssessmentCheckedForm_Load(object sender, EventArgs e)
        //{
        //    listPanel.Add(panel1);
        //    listPanel.Add(panel2);
        //    listPanel[index].BringToFront();
        //    MessageBox.Show("Dog" + listPanel.Count.ToString());
        //}

        private void AddPanels()
        {
            listPanel.Add(panel1);
            listPanel.Add(panel2);
            listPanel[index].BringToFront();
            backButton.Visible = false;
            submitButton.Visible = false;
            nextButton.Visible = true;
            closeButton.Visible = true;
        }

        private void nextButton_Click(object sender, EventArgs e)
        {
            listPanel[1].BringToFront();
            nextButton.Visible = false;
            submitButton.Visible = true;
            backButton.Visible = true;
            closeButton.Visible = false;
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            listPanel[0].BringToFront();
            closeButton.Visible = true;
            backButton.Visible = false;
            nextButton.Visible = true;
            submitButton.Visible = false;

        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void submitButton_Click(object sender, EventArgs e)
        {
            string error = "";
            if (ammendments.Text.Contains('*'))
            {
                error += "Comments cannot contain the illegal character '*'\n";
            }
            if(ammendments.Text == "")
            {
                error += "Please fill in ammendment comments";
            }
            if(error != "")
            {
                MessageBox.Show(error);
            }
            else
            {
                m_Assessment.AddAmmendText(ammendments.Text);
                this.Close();
            }
        }
        #endregion

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void Q2Label_Click(object sender, EventArgs e)
        {

        }

        private void modNumText_TextChanged(object sender, EventArgs e)
        {

        }

        private void backButton_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

    }
}
