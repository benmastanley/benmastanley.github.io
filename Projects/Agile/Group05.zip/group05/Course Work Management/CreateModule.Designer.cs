﻿namespace Course_Work_Management
{
    partial class CreateModule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.modNameText = new System.Windows.Forms.TextBox();
            this.modCodeText = new System.Windows.Forms.TextBox();
            this.numOfStudText = new System.Windows.Forms.TextBox();
            this.cancelBut = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.modManCombo = new System.Windows.Forms.ComboBox();
            this.facultyCombo = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(63, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Module Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(63, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Module Code:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(63, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Number of Students:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(63, 173);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Module Manager:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(63, 203);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Faculty:";
            // 
            // modNameText
            // 
            this.modNameText.Location = new System.Drawing.Point(194, 72);
            this.modNameText.Name = "modNameText";
            this.modNameText.Size = new System.Drawing.Size(100, 20);
            this.modNameText.TabIndex = 5;
            this.modNameText.TextChanged += new System.EventHandler(this.modNameText_TextChanged);
            // 
            // modCodeText
            // 
            this.modCodeText.Location = new System.Drawing.Point(194, 103);
            this.modCodeText.Name = "modCodeText";
            this.modCodeText.Size = new System.Drawing.Size(100, 20);
            this.modCodeText.TabIndex = 6;
            this.modCodeText.TextChanged += new System.EventHandler(this.modCodeText_TextChanged);
            // 
            // numOfStudText
            // 
            this.numOfStudText.Location = new System.Drawing.Point(194, 138);
            this.numOfStudText.Name = "numOfStudText";
            this.numOfStudText.Size = new System.Drawing.Size(100, 20);
            this.numOfStudText.TabIndex = 7;
            this.numOfStudText.TextChanged += new System.EventHandler(this.numOfStudText_TextChanged);
            // 
            // cancelBut
            // 
            this.cancelBut.Location = new System.Drawing.Point(589, 394);
            this.cancelBut.Name = "cancelBut";
            this.cancelBut.Size = new System.Drawing.Size(75, 23);
            this.cancelBut.TabIndex = 10;
            this.cancelBut.Text = "Cancel";
            this.cancelBut.UseVisualStyleBackColor = true;
            this.cancelBut.Click += new System.EventHandler(this.cancelBut_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(684, 394);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 11;
            this.button2.Text = "Okay";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // modManCombo
            // 
            this.modManCombo.FormattingEnabled = true;
            this.modManCombo.Location = new System.Drawing.Point(173, 170);
            this.modManCombo.Name = "modManCombo";
            this.modManCombo.Size = new System.Drawing.Size(121, 21);
            this.modManCombo.TabIndex = 12;
            this.modManCombo.SelectedIndexChanged += new System.EventHandler(this.modManCombo_SelectedIndexChanged);
            // 
            // facultyCombo
            // 
            this.facultyCombo.FormattingEnabled = true;
            this.facultyCombo.Location = new System.Drawing.Point(173, 197);
            this.facultyCombo.Name = "facultyCombo";
            this.facultyCombo.Size = new System.Drawing.Size(121, 21);
            this.facultyCombo.TabIndex = 13;
            this.facultyCombo.SelectedIndexChanged += new System.EventHandler(this.facultyCombo_SelectedIndexChanged);
            // 
            // CreateModule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.facultyCombo);
            this.Controls.Add(this.modManCombo);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.cancelBut);
            this.Controls.Add(this.numOfStudText);
            this.Controls.Add(this.modCodeText);
            this.Controls.Add(this.modNameText);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "CreateModule";
            this.Text = "CreateModule";
            this.Load += new System.EventHandler(this.CreateModule_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox modNameText;
        private System.Windows.Forms.TextBox modCodeText;
        private System.Windows.Forms.TextBox numOfStudText;
        private System.Windows.Forms.Button cancelBut;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox modManCombo;
        private System.Windows.Forms.ComboBox facultyCombo;
    }
}