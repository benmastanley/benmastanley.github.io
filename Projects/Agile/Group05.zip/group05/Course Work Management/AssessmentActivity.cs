﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course_Work_Management
{
    public partial class AssessmentActivity : Form
    {
        private ModuleManager m_ModuleManager = null;
        private CheckedAssessment m_Assessment = null;

        public AssessmentActivity()
        {
            InitializeComponent();
        }

        public AssessmentActivity(ModuleManager pManager) : this()
        {
            m_ModuleManager = pManager;
            refreshListBox();
        }

        private void refreshListBox()
        {
            List<Module> tempList = m_ModuleManager.GetManagersModules;
            List<CheckedAssessment> checkedList = new List<CheckedAssessment>();
            List<CheckedAssessment> uncheckedList = new List<CheckedAssessment>();

            for (int i = 0; i < tempList.Count; i++)
            {
                for (int j = 0; j < Program.checkedAssessList.Count; j++)
                {
                    if((Program.checkedAssessList[j].GetModuleCode == tempList[i].GetModuleCode))
                    {
                        if(Program.checkedAssessList[j].GetAmmendments == "")
                        {
                            uncheckedList.Add(Program.checkedAssessList[j]);
                        }
                        else
                        {
                            checkedList.Add(Program.checkedAssessList[j]);
                        }
                    }
                }
            }
            for (int i = 0; i < uncheckedList.Count; i++)
            {
                listBox1.Items.Add(Program.checkedAssessList[i]);
            }
            for (int i = 0; i < checkedList.Count; i++)
            {
                listBox1.Items.Add(Program.checkedAssessList[i]);
            }

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_Assessment = (CheckedAssessment)listBox1.SelectedItem;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (m_Assessment == null)
            {
                MessageBox.Show("Please select an assessment");
            }
            else
            {
                AssessmentCheckedForm form1 = new AssessmentCheckedForm(m_Assessment);
                form1.Show();
            }
        }
    }
}
