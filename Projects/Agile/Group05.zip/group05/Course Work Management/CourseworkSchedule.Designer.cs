﻿namespace Course_Work_Management
{
    partial class CourseworkSchedule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.usersPanel = new System.Windows.Forms.TableLayoutPanel();
            this.calendarFlow = new System.Windows.Forms.FlowLayoutPanel();
            this.datePanel = new System.Windows.Forms.TableLayoutPanel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.facultyCombo = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.closeBut = new System.Windows.Forms.Button();
            this.calendarFlow.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(383, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Calendar";
            // 
            // usersPanel
            // 
            this.usersPanel.AutoSize = true;
            this.usersPanel.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.usersPanel.ColumnCount = 3;
            this.usersPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.usersPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.usersPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 140F));
            this.usersPanel.Location = new System.Drawing.Point(12, 88);
            this.usersPanel.Name = "usersPanel";
            this.usersPanel.RowCount = 1;
            this.usersPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 21F));
            this.usersPanel.Size = new System.Drawing.Size(364, 23);
            this.usersPanel.TabIndex = 3;
            // 
            // calendarFlow
            // 
            this.calendarFlow.AutoScroll = true;
            this.calendarFlow.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.calendarFlow.Controls.Add(this.datePanel);
            this.calendarFlow.Location = new System.Drawing.Point(382, 63);
            this.calendarFlow.Name = "calendarFlow";
            this.calendarFlow.Size = new System.Drawing.Size(707, 367);
            this.calendarFlow.TabIndex = 4;
            this.calendarFlow.WrapContents = false;
            // 
            // datePanel
            // 
            this.datePanel.AutoSize = true;
            this.datePanel.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.datePanel.ColumnCount = 1;
            this.datePanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.datePanel.Location = new System.Drawing.Point(3, 3);
            this.datePanel.Name = "datePanel";
            this.datePanel.RowCount = 1;
            this.datePanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.datePanel.Size = new System.Drawing.Size(62, 22);
            this.datePanel.TabIndex = 0;
            this.datePanel.Paint += new System.Windows.Forms.PaintEventHandler(this.datesPanel_Paint);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(1007, 36);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(82, 21);
            this.comboBox1.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(969, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Year:";
            // 
            // facultyCombo
            // 
            this.facultyCombo.FormattingEnabled = true;
            this.facultyCombo.Location = new System.Drawing.Point(842, 36);
            this.facultyCombo.Name = "facultyCombo";
            this.facultyCombo.Size = new System.Drawing.Size(121, 21);
            this.facultyCombo.TabIndex = 7;
            this.facultyCombo.SelectedIndexChanged += new System.EventHandler(this.facultyCombo_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(792, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Faculty:";
            // 
            // closeBut
            // 
            this.closeBut.Location = new System.Drawing.Point(1014, 551);
            this.closeBut.Name = "closeBut";
            this.closeBut.Size = new System.Drawing.Size(75, 23);
            this.closeBut.TabIndex = 9;
            this.closeBut.Text = "Close";
            this.closeBut.UseVisualStyleBackColor = true;
            this.closeBut.Click += new System.EventHandler(this.closeBut_Click);
            // 
            // CourseworkSchedule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1106, 586);
            this.Controls.Add(this.closeBut);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.facultyCombo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.calendarFlow);
            this.Controls.Add(this.usersPanel);
            this.Controls.Add(this.label1);
            this.Name = "CourseworkSchedule";
            this.Text = "CourseworkSchedule";
            this.calendarFlow.ResumeLayout(false);
            this.calendarFlow.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel usersPanel;
        private System.Windows.Forms.FlowLayoutPanel calendarFlow;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TableLayoutPanel datePanel;
        private System.Windows.Forms.ComboBox facultyCombo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button closeBut;
    }
}