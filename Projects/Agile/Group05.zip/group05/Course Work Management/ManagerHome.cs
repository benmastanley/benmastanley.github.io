﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course_Work_Management
{
    public partial class Manager_Home : Form
    {
        private ModuleManager m_ModuleManager = null;
        public Manager_Home()
        {
            InitializeComponent();
        }

        public Manager_Home(ModuleManager pManager): this()
        {
            m_ModuleManager = pManager;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ModuleEdit form = new ModuleEdit(m_ModuleManager);
            form.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AssessmentActivity form = new AssessmentActivity(m_ModuleManager);
            form.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CourseworkSchedule form = new CourseworkSchedule(m_ModuleManager);
            form.Show();
        }
    }
}
