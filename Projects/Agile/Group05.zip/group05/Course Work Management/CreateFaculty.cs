﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course_Work_Management
{
    public partial class CreateFaculty : Form
    {
        private Faculty m_faculty = null;
        private ProgrammeDirector m_Director = null;

        public CreateFaculty()
        {
            InitializeComponent();
            LoadDirectors();
        }

        private void LoadDirectors()
        {
            for(int i = 0; i < Program.PDList.Count; i++)
            {
                directorCombo.Items.Add(Program.PDList[i]);
            }
        }

        private void CreateFaculty_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string error = "";
            string facultyName = "";

            if (facName.Text == "")
            {
                error += "Faculty Name cannot be blank\n";
            }
            if (facName.Text.Contains('*'))
            {
                error += "Faculty name cannot contain illegal character '*'\n";
            }
            if (facName.Text.Contains(','))
            {
                error += "Faculty name cannot contain illegal character ','\n";
            }
            for(int i = 0; i < Program.facultyList.Count; i++)
            {
                if(Program.facultyList[i].GetFacultyName == facName.Text)
                {
                    error += "Faculty name already exists\n";
                }
            }
            if (m_Director == null)
            {
                error += "Please select a programme director from the list\n";
            }
            if (error == "")
            {
                facultyName = facName.Text;
                Program.facultyList.Add(new Faculty(facultyName, m_Director));
                MessageBox.Show("New faculty created: " + facultyName+ "\r\n" + "Faculty Director : " + m_Director.GetForename + " " + m_Director.GetSurname);
                this.Close();
            }
            else
            {
                MessageBox.Show(error);
            }
        }

        private void directorCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_Director = (ProgrammeDirector)directorCombo.SelectedItem;
        }
    }
}
