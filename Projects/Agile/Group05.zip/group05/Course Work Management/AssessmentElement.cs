﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course_Work_Management
{
    public partial class AssessmentElement : Form
    {
        private ModuleManager m_ModuleManager = null;
        private Assessment m_Assessment = null;
        private ModuleChecker m_moduleChecker = null;
        private Module m_Module = null;

        //Form constructors depending what the form gets given
        public AssessmentElement()
        {
            InitializeComponent();
            findCheckers();
            ModName.ReadOnly = true;
        }

        //For a new form
        public AssessmentElement(ModuleManager pManager) : this()
        {
            m_ModuleManager = pManager;
            RefreshCodes();
        }

        //For editing a form, loads data in
        public AssessmentElement(ModuleManager pManager, Assessment pAssessment) : this()
        {
            m_ModuleManager = pManager;
            m_Assessment = pAssessment;
            AssessCode.Text = m_Assessment.GetAssessmentCode;
            AssessName.Text = m_Assessment.GetAssessmentName;
            AssessType.Text = m_Assessment.GetAssessmentType;
            ModName.Text = m_Assessment.GetModuleName;
            //ModCode.Text = m_Assessment.GetModuleCode;
            modCodesCombo.Text = m_Assessment.GetModuleCode;
            PercentOfMod.Text = m_Assessment.GetPercentageGrade.ToString();
            NumOfStud.Text = m_Assessment.GetNumOfStudents.ToString();
            Session.Text = m_Assessment.GetSession;
            ReleaseDate.Text = m_Assessment.GetReleaseDate.ToString("dd/MM/yyyy");
            SubDate.Text = m_Assessment.GetSubmissionDate.ToString("dd/MM/yyyy");
            permitExt.Text += " " + m_Assessment.GetExtensionDate.ToString("dd/MM/yyyy");
            feedbackDate.Text += " " + m_Assessment.GetExtensionDate.ToString("dd/MM/yyyy");
            RefreshCodes();
        }

        private void findCheckers()
        {
            for(int i = 0; i < Program.checkersList.Count; i++)
            {
                checkerCombo.Items.Add(Program.checkersList[i]);
            }
        }

        private void OkButton_Click(object sender, EventArgs e)
        {
            string error = "";
            // checks if any of the text boxes are empty  || ModCode.Text == "" 
            if (AssessCode.Text == "" || AssessName.Text == "" || AssessType.Text == "" || ModName.Text == "" ||
                PercentOfMod.Text == "" || NumOfStud.Text == "" || Session.Text == "" || ReleaseDate.Text == "" || SubDate.Text == "")
            { MessageBox.Show("Fields can't be empty"); }

            else
            {
                //checks if assessment code is an int
                string assessCode = AssessCode.Text;
                try { Convert.ToInt32(AssessCode.Text); assessCode = AssessCode.Text; }
                catch
                {
                    error += "Assesment code must be a number\n";
                }
                // Checks if the assessment code already exist
                for (int i = 0; i < Program.assessList.Count; i++)
                {
                    if (Program.assessList[i].GetAssessmentCode == assessCode)
                    {
                        error += "Assessment code alredy exist. Please use different one\n";
                    }
                }

                //Validate user input and checks if there are any invalid character
                string assesName = AssessName.Text;
                string assesType = AssessType.Text;

                string pattern = "^[0-9A-Za-z ]+$";
                Regex regex = new Regex(pattern);
                if (regex.IsMatch(assesName) == false)
                {
                    error += ("Invalid character");

                }
                if (regex.IsMatch(assesType) == false)
                {
                    error += ("Invalid character");

                }

                string moduleCode = "";
                string moduleName = "";

                //Checks if module has been selected from list
                if(m_Module == null)
                {
                    error += "Please select a module from the list, or create a new one\n";
                }
                else
                {
                    moduleCode = m_Module.GetModuleCode;
                    moduleName = m_Module.GetModuleName;
                }


                // trys to convert percentage of module to number
                int percentOfMod = 0;
                try{ percentOfMod = Convert.ToInt32(PercentOfMod.Text); }
                catch
                {
                    error += "Percentage of module must be a number\n";
                }

                //Checks if percentage is not over 100
                if (percentOfMod >= 101)
                {
                    error += "Percentage must be 100 or lower\n";
                }

                int numOfStud = 0;
                try
                {
                    numOfStud = int.Parse(NumOfStud.Text);
                }
                catch
                {
                    error += "Number of students field must be interger only\n";
                }

                string session = Session.Text;


                DateTime extensionDate = new DateTime();
                DateTime feedbackDate = new DateTime();

                // parses release date string to a datetime format
                DateTime releaseDate = new DateTime();
                try { releaseDate = DateTime.ParseExact(ReleaseDate.Text, "dd/MM/yyyy", new CultureInfo("en-GB")); } catch
                {
                    error += "Incorrect format for the release date\n";
                }

                // parses submission date string to a datetime format
                DateTime subDate = new DateTime();
                try { subDate = DateTime.ParseExact(SubDate.Text, "dd/MM/yyyy", new CultureInfo("en-GB")); }
                catch
                {
                    error += "Incorrect format for the submission date\n";
                }

                if(checkerCombo.SelectedItem == null)
                {
                    error += "An assessment checker must be selected from the list\n";
                }

                string folderLocation = Path.Combine(AppDomain.CurrentDomain.BaseDirectory) + @"CourseworkFiles\";    // location where the chosen file will be saved
                if (uploadingFile)  // if a file is being uploaded it will save the file in the CourseworkFiles directory
                {
                    if (System.IO.Directory.Exists(folderLocation)) // checks to make sure folderLocation exists
                    {
                        try
                        {
                            System.IO.File.Copy(fileToCopy, folderLocation + Path.GetFileName(fileToCopy));    // copies file
                            MessageBox.Show("File succesfully uploaded");
                        }
                        catch
                        {
                            error += "File already exists";
                        }

                    }
                    else
                    {
                        error += "The CourseworkFiles folder could not be found";
                    }
                }
                else
                {
                    error += "Please select a file to upload";
                }

                // if there are no errors then creates a new assesment 
                if (error == "")
                {


                    extensionDate = subDate;
                    feedbackDate = subDate;
                    extensionDate.AddDays(7);   
                    feedbackDate.AddDays(28);
                    //Adds assessment to the list and then saves it to a new line on the text file
                    m_Assessment = new Assessment(assessCode, assesName, assesType, moduleName, moduleCode, percentOfMod, numOfStud, session, releaseDate, subDate, extensionDate, feedbackDate, false, folderLocation + Path.GetFileName(fileToCopy));
                    Program.assessList.Add(m_Assessment);
                    m_moduleChecker.AddToList(m_Assessment);
                    if (!m_ModuleManager.GetModuleCodes.Contains(m_Assessment.GetModuleCode))
                    {
                        m_ModuleManager.AddToCodesList(m_Assessment.GetModuleCode);
                    }


                    using (StreamWriter sw = File.AppendText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assessments.txt")))
                    {
                        sw.WriteLine(assessCode + "," + assesName + "," + assesType + "," + moduleName + "," + moduleCode + "," + percentOfMod + "," + numOfStud + "," + session + "," + releaseDate.ToString("dd/MM/yyyy") + "," + subDate.ToString("dd/MM/yyyy") + "," + extensionDate.ToString("dd/MM/yyyy") + "," + feedbackDate.ToString("dd/MM/yyyy") + "," + "false" + "," + folderLocation + Path.GetFileName(fileToCopy));
                    }
                    MessageBox.Show("Assessment created");

                    this.Close();
                }
                else
                {
                    MessageBox.Show(error);
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_moduleChecker = (ModuleChecker)checkerCombo.SelectedItem;
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CreateModule form = new CreateModule();
            form.Show();
            form.FormClosed += new FormClosedEventHandler(Form_Closed);
        }

        private void Form_Closed(object sender, FormClosedEventArgs e)
        {
            RefreshCodes();
        }

        private void RefreshCodes()
        {
            modCodesCombo.Items.Clear();
            List<string> tempCodes = m_ModuleManager.GetModuleCodes;
            for(int i = 0; i < tempCodes.Count; i++)
            {
                for (int j = 0; j < Program.moduleList.Count; j++)
                {
                    if (tempCodes[i] == Program.moduleList[j].GetModuleCode)
                    {
                        modCodesCombo.Items.Add(Program.moduleList[j]);
                    }
                }
            }
        }

        private void modCodesCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            //string modCode = modCodesCombo.SelectedItem.ToString();
            m_Module = (Module)modCodesCombo.SelectedItem;
            ModName.Text = m_Module.GetModuleName;
        }

        bool uploadingFile = false;
        string fileToCopy = "";

        private void uploadFileButton_Click(object sender, EventArgs e)
        {
            uploadingFile = true;
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Microsoft Word Document (*.docx *.doc)|*.docx; *.doc; |PDF File (*.pdf)|*.pdf;"; // file types, that will be allowed to upload
            dialog.FilterIndex = 1;
            dialog.Multiselect = false; // allow/deny user to upload more than one file at a time

            if (dialog.ShowDialog() == DialogResult.OK) // if user clicked OK
            {
                fileToCopy = dialog.FileName; // saves location of the file seleceted by user


            }
        }

        private void AssessmentElement_Load(object sender, EventArgs e)
        {

        }

        private void AssessCode_TextChanged(object sender, EventArgs e)
        {

        }


        private void AssessName_TextChanged(object sender, EventArgs e)
        {

        }

        private void AssessType_TextChanged(object sender, EventArgs e)
        {

        }

        private void ModName_TextChanged(object sender, EventArgs e)
        {

        }

        private void ModCode_TextChanged(object sender, EventArgs e)
        {

        }

        private void PercentOfMod_TextChanged(object sender, EventArgs e)
        {

        }

        private void NumOfStud_TextChanged(object sender, EventArgs e)
        {

        }

        private void Session_TextChanged(object sender, EventArgs e)
        {

        }

        private void ReleaseDate_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void SubDate_TextChanged(object sender, EventArgs e)
        {

        }     
    }
}
