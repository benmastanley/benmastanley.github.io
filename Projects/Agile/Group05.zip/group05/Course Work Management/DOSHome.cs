﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course_Work_Management
{
    public partial class DOSHome : Form
    {
        private DirOfStudies m_DirOfStudies = null;

        public DOSHome()
        {
            InitializeComponent();
        }

        public DOSHome(DirOfStudies pDirOfStudies):this()
        {
            m_DirOfStudies = pDirOfStudies;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AllModules DOSAllModules = new AllModules();
            DOSAllModules.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ModuleManagers DOSModuleManagers = new ModuleManagers();
            DOSModuleManagers.Show();
            this.Hide();
        }

        private void facultyBut_Click(object sender, EventArgs e)
        {
            CreateFaculty form = new CreateFaculty();
            form.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CourseworkSchedule form = new CourseworkSchedule();
            form.Show();
        }
    }
}
    