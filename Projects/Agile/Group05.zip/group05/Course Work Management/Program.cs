﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Course_Work_Management
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// Loads the data in from the text files, and stores them in lists. Starts a new log in screen for user to enter credentials.
        /// </summary>
        [STAThread]
        static void Main()
        {
            LoadData();
            LoadUsers();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LoginScreen());
            SaveData();
            SaveUserData();
        }

        //List of different data to keep in program memory when running to access easily
        public static List<Module> moduleList = new List<Module>();
        public static List<Assessment> assessList = new List<Assessment>();
        public static List<CheckedAssessment> checkedAssessList = new List<CheckedAssessment>();
        public static List<Faculty> facultyList = new List<Faculty>();
        
        public static List<ModuleManager> managersList = new List<ModuleManager>();
        public static List<ModuleChecker> checkersList = new List<ModuleChecker>();
        public static List<DirOfStudies> DoSList = new List<DirOfStudies>();
        public static List<ProgrammeDirector> PDList = new List<ProgrammeDirector>();

        //Loads users in from the diffferent text files and calls the specific account constructors so objects are made from them
        public static void LoadUsers()
        {
            string[] managerLines = File.ReadAllLines("Managers.txt");
            for(int i = 0; i < managerLines.Length; i++)
            {
                string[] linesplit = managerLines[i].Split(',');
                managersList.Add(new ModuleManager(linesplit[0], linesplit[1], linesplit[2], linesplit[3], linesplit[4], linesplit[5]));
            }

            string[] checkerLines = File.ReadAllLines("Checkers.txt");
            for (int i = 0; i < checkerLines.Length; i++)
            {
                string[] linesplit = checkerLines[i].Split(',');
                checkersList.Add(new ModuleChecker(linesplit[0], linesplit[1], linesplit[2], linesplit[3], linesplit[4], linesplit[5]));
            }

            string[] DoSLines = File.ReadAllLines("DirectorOfStudies.txt");
            for (int i = 0; i < DoSLines.Length; i++)
            {
                string[] linesplit = DoSLines[i].Split(',');
                DoSList.Add(new DirOfStudies(linesplit[0], linesplit[1], linesplit[2], linesplit[3], linesplit[4]));
            }
        }

        //Loads data in from the diffferent text files and calls the specific constructors so objects are made from them
        public static void LoadData()
        {
            string[] PDLines = File.ReadAllLines("ProgrammeDirectors.txt");
            for (int i = 0; i < PDLines.Length; i++)
            {
                string[] linesplit = PDLines[i].Split(',');
                PDList.Add(new ProgrammeDirector(linesplit[0], linesplit[1], linesplit[2], linesplit[3], linesplit[4]));
            }

            //Reads assessments file, and converts the data to add to the assessment list
            string[] lines = File.ReadAllLines("Assessments.txt");
            for (int x = 0; x < lines.Length; x++)
            {
                string[] linesplit = lines[x].Split(',');
                string date1 = linesplit[8];
                string date2 = linesplit[9];
                string date3 = linesplit[10];
                string date4 = linesplit[11];
                DateTime RelDate = DateTime.Parse(date1);
                DateTime SubDate = DateTime.Parse(date1);
                DateTime ExDate = DateTime.Parse(date1);
                DateTime FeedDate = DateTime.Parse(date1);
                string check = linesplit[12];
                bool modChecked = Convert.ToBoolean(check);
                assessList.Add(new Assessment(linesplit[0], linesplit[1], linesplit[2], linesplit[3], linesplit[4], int.Parse(linesplit[5]), int.Parse(linesplit[6]), linesplit[7], RelDate, SubDate, ExDate, FeedDate, modChecked, linesplit[13]));
            }

            //Reads modules file, loads data to the module list
            lines = File.ReadAllLines("Modules.txt");
            for(int x = 0; x < lines.Length; x++)
            {
                string[] linesplit = lines[x].Split(',');
                moduleList.Add(new Module(linesplit[0], linesplit[1], int.Parse(linesplit[2]), linesplit[3], linesplit[4]));
            }

            lines = File.ReadAllLines("CheckedAssessments.txt");
            for (int x = 0; x < lines.Length; x++)
            {
                string[] linesplit = lines[x].Split('*');
                List<int> intList = new List<int>();
                DateTime RelDate = DateTime.Parse(linesplit[8]);
                DateTime SubDate = DateTime.Parse(linesplit[9]);
                DateTime ExDate = DateTime.Parse(linesplit[10]);
                DateTime FeedDate = DateTime.Parse(linesplit[11]);
                DateTime ApprovedDate = DateTime.Parse(linesplit[30]);
                for (int i = 16; i < 28; i++)
                {
                    intList.Add(int.Parse(linesplit[i]));
                }
                checkedAssessList.Add(new CheckedAssessment(linesplit[0], linesplit[1], linesplit[2], linesplit[3], linesplit[4], int.Parse(linesplit[5]), int.Parse(linesplit[6]), linesplit[7], RelDate, SubDate,
                    ExDate, FeedDate, Convert.ToBoolean(linesplit[12]), linesplit[13], linesplit[4], linesplit[15], intList,
                    linesplit[28], int.Parse(linesplit[29]), ApprovedDate, Convert.ToBoolean(linesplit[31]), linesplit[32]));
            }

            lines = File.ReadAllLines("Faculties.txt");
            for (int x = 0; x < lines.Length; x++)
            {
                string[] linesplit = lines[x].Split(',');
                facultyList.Add(new Faculty(linesplit[0], linesplit[1]));
            }
        }

        //Clears text files and saves new data from lists into them
        public static void SaveData()
        {
            File.WriteAllText("Assessments.txt", String.Empty);
            using (StreamWriter outputFile = new StreamWriter("Assessments.txt"))
            {
                for (int i = 0; i < assessList.Count; i++)
                {
                    outputFile.WriteLine(assessList[i].GetAllDetails);
                }
            }

            File.WriteAllText("Modules.txt", String.Empty);
            using (StreamWriter outputFile = new StreamWriter("Modules.txt"))
            {
                for (int i = 0; i < moduleList.Count; i++)
                {
                    outputFile.WriteLine(moduleList[i].GetAllModDetails);
                }
            }

            File.WriteAllText("CheckedAssessments.txt", String.Empty);
            using (StreamWriter outputFile = new StreamWriter("CheckedAssessments.txt"))
            {
                for (int i = 0; i < checkedAssessList.Count; i++)
                {
                    outputFile.WriteLine(checkedAssessList[i].GetAllCheckedDetails());
                }
            }

            File.WriteAllText("Faculties.txt", String.Empty);
            using (StreamWriter outputFile = new StreamWriter("Faculties.txt"))
            {
                for (int i = 0; i < facultyList.Count; i++)
                {
                    outputFile.WriteLine(facultyList[i].GetAllDetails());
                }
            }
        }

        public static void SaveUserData()
        {
            File.WriteAllText("Managers.txt", String.Empty);
            using (StreamWriter outputFile = new StreamWriter("Managers.txt"))
            {
                for (int i = 0; i < managersList.Count; i++)
                {
                    string moduleCodes = "";
                    List<string> modCodeList = managersList[i].GetModuleCodes;
                    List<string> newCodeList = new List<string>();

                    for(int j = 0; j < modCodeList.Count; j++)
                    {
                        if (!newCodeList.Contains(modCodeList[j]))
                        {
                            newCodeList.Add(modCodeList[j]);
                        }
                    }
                    for(int k = 0; k <newCodeList.Count; k++)
                    {
                        if (k < newCodeList.Count - 1)
                        {
                            moduleCodes += newCodeList[k] + "*";
                        }
                        else
                        {
                            moduleCodes += newCodeList[k];
                        }
                    }
                    outputFile.WriteLine(managersList[i].GetUsername + "," + managersList[i].GetPassword + "," + managersList[i].GetUserType + "," + managersList[i].GetForename + "," + managersList[i].GetSurname + "," + moduleCodes);
                }
            }
        }
    }

    //Data and constructors for accounts
    public class Account
    {
        #region Member variables
        private string m_Username;
        private string m_Password;
        private string m_UserType;
        private string m_Forename;
        private string m_Surname;
        #endregion

        #region Get variables
        public string GetUsername
        {
            get { return m_Username; }
        }

        public string GetPassword
        {
            get { return m_Password; }
        }
        public string GetUserType
        {
            get { return m_UserType; }
        }
        public string GetForename
        {
            get { return m_Forename; }
        }

        public string GetSurname
        {
            get { return m_Surname; }
        }
        #endregion

        #region Set variables
        public bool SetUsername(string pUsername)
        {
            m_Username = pUsername;
            return true;
        }
        public bool SetPassword(string pPassword)
        {
            m_Password = pPassword;
            return true;
        }
        public bool SetUserType(string pUserType)
        {
            m_UserType = pUserType;
            return true;
        }
        public bool SetForename(string pForename)
        {
            m_Forename = pForename;
            return true;
        }
        public bool SetSurname(string pSurname)
        {
            m_Surname = pSurname;
            return true;
        }
        #endregion

        #region Validators
        private static bool ValidateForename(string pforename, out string pError) //Validates forename
        {
            pError = "";

            pforename = pforename.Trim();
            if (pforename.Length == 0) //Checks if name entered is 0
            {
                pError += "Forename cannot be blank.\r\n";
            }

            if (!LettersOnly(pforename)) //Checks if name contains letters only
            {
                pError += "Forename must only contain letters.\r\n";
            }

            return (pError.Length == 0); //Returns
        }

        private static bool ValidateSurname(string pSurname, out string pError) //Validates surname
        {
            pError = "";

            pSurname = pSurname.Trim();
            if (pSurname.Length == 0)
            {
                pError += "Surname name cannot be blank.\r\n";
            }

            if (!LettersOnly(pSurname))
            {
                pError += "Surname name must only contain letters.\r\n";
            }

            return (pError.Length == 0);
        }

        private static bool LettersOnly(string pString)
        {
            char[] alphabet = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i',
                'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's',
                't', 'u', 'v', 'w', 'x', 'y', 'z' };
            foreach (char ch in pString.ToLower())
            {
                bool illegalCharacter = false;
                for (int i = 0; i < alphabet.Length; i++)
                {
                    illegalCharacter = true;
                    if (ch == alphabet[i])
                    {
                        illegalCharacter = false;
                        break;
                    }
                }
                if (illegalCharacter)
                {
                    return false;
                }
            }
            return true;
        }
        #endregion
    }

    public class ModuleManager : Account                    // ------------ ADDED MODULES MANAGED LIST PARAMETER/MEMBER VARIABLE
    {                                                       // ------------ CONTAINS LIST OF ALL MODULES FOR EACH MODULE MANAGER
        private List<Module> managersModules = new List<Module>();
        private List<Assessment> assessmentList = new List<Assessment>();
        private List<string> moduleCodes = new List<string>();
        private List<CheckedAssessment> m_CheckedAssess = new List<CheckedAssessment>();

        #region Get/Add lists
        public List<Module> GetManagersModules
        {
            get { return managersModules; }
        }
        public List<Assessment> GetAssessmentList
        {
            get { return assessmentList; }
        }
        public List<string> GetModuleCodes
        {
            get { return moduleCodes; }
        }
        public List<CheckedAssessment> GetCheckedAssess
        {
            get { return m_CheckedAssess; }
        }
        public bool AddToModList(Module pModule)
        {
            managersModules.Add(pModule);
            return true;
        }
        public bool AddToAssessList(Assessment pAssessment)
        {
            assessmentList.Add(pAssessment);
            return true;
        }
        public bool AddToCodesList(string pModCode)
        {
            moduleCodes.Add(pModCode);
            return true;
        }
        public bool AddToCheckedList(CheckedAssessment pCheckedAssess)
        {
            m_CheckedAssess.Add(pCheckedAssess);
            return true;
        }
        #endregion

        public override string ToString()
        {
            return GetForename + " " + GetSurname;
        }

        public ModuleManager(string pUsername, string pPassword, string pUserType, string pForename, string pSurname, string pModulesManaged)
        {
            this.SetUsername(pUsername);
            this.SetPassword(pPassword);
            this.SetUserType(pUserType);
            this.SetForename(pForename);
            this.SetSurname(pSurname);
            string[] modulesSplit = pModulesManaged.Split('*');
            for (int i = 0; i < modulesSplit.Length; i++)
            {
                moduleCodes.Add(modulesSplit[i]);
                bool found = false;
                for (int j = 0; j < Program.moduleList.Count; j++)
                {

                    if (Program.moduleList[j].GetModuleCode == modulesSplit[i])
                    {
                        //managersModules.Add(Program.moduleList[j]);
                        AddToModList(Program.moduleList[j]);
                        found = true;
                    }
                }
                if (found == false)
                {
                    MessageBox.Show("Module code: " + modulesSplit[i] + " not found");
                }
            }
        }
    }

    public class ModuleChecker : Account
    {
        private List<Assessment> assessmentsToCheck = new List<Assessment>();
        private List<Assessment> doneAssessments = new List<Assessment>();

        public override string ToString()
        {
            return GetForename + " " + GetSurname;
        }

        #region Get/Add lists
        public List<Assessment> GetAssessToCheck
        {
            get { return assessmentsToCheck; }
        }
        public List<Assessment> GetAssessDone
        {
            get { return doneAssessments; }
        }
        public bool AddToList(Assessment pAssessment)
        {
            assessmentsToCheck.Add(pAssessment);
            return true;
        }
        public bool AddToDoneList(Assessment pAssessment)
        {
            doneAssessments.Add(pAssessment);
            return true;
        }
        public bool MoveListItem(string pAssessmentCode)
        {
            for(int i = 0; i < assessmentsToCheck.Count; i++)
            {
                if(assessmentsToCheck[i].GetAssessmentCode == pAssessmentCode)
                {
                    doneAssessments.Add(assessmentsToCheck[i]);
                    assessmentsToCheck.Remove(assessmentsToCheck[i]);
                    break;
                }
            }
            return true;
        }
        #endregion

        public ModuleChecker(string pUsername, string pPassword, string pUserType, string pForename, string pSurname, string pAssessments)
        {
            this.SetUsername(pUsername);
            this.SetPassword(pPassword);
            this.SetUserType(pUserType);
            this.SetForename(pForename);
            this.SetSurname(pSurname);
            //Gets individual assessment codes, then checks if there's an assessment with matching code and adds it to the checkers list to check
            string[] codesSplit = pAssessments.Split('*');
            for (int i = 0; i < codesSplit.Length; i++)
            {
                bool found = false;
                for (int j = 0; j < Program.assessList.Count; j++)
                {

                    if (Program.assessList[j].GetAssessmentCode == codesSplit[i])
                    {
                        if (Program.assessList[j].GetChecked == false)
                        {
                            assessmentsToCheck.Add(Program.assessList[j]);
                        }
                        else
                        {
                            doneAssessments.Add(Program.assessList[j]);
                        }
                        //MessageBox.Show("Found assessment: " + Program.assessList[j].GetAssessmentName);
                        found = true;
                    }
                }
                if (found == false)
                {
                    MessageBox.Show("Assessment code: " + codesSplit[i] + " not found");
                }
            }
        }
    }

    public class ProgrammeDirector : Account
    {
        private List<Faculty> m_PDFaculties;

        public override string ToString()
        {
            return GetForename + " " + GetSurname;
        }

        public ProgrammeDirector(string pUsername, string pPass, string pUserType, string pForename, string pSurname)
        {
            this.SetUsername(pUsername);
            this.SetPassword(pPass);
            this.SetUserType(pUserType);
            this.SetForename(pForename);
            this.SetSurname(pSurname);
        }
    }

    public class DirOfStudies : Account
    {
        public DirOfStudies(string pUsername, string pPass, string pUserType, string pForename, string pSurname)
        {
            this.SetUsername(pUsername);
            this.SetPassword(pPass);
            this.SetUserType(pUserType);
            this.SetForename(pForename);
            this.SetSurname(pSurname);
        }
    }

    public class Faculty
    {
        ProgrammeDirector m_FacultyDirector; //Set it to the correct programme director
        private List<Module> moduleList = new List<Module>();
        private List<ModuleManagers> facultyManagersList = new List<ModuleManagers>();
        private string m_FacultyName = "";
        private string m_FacultyDirStr;

        public string GetFacultyName
        {
            get { return m_FacultyName; }
        }

        public override string ToString()
        {
            return GetFacultyName;
        }

        public string GetAllDetails()
        {
            return m_FacultyName + "," + m_FacultyDirector.GetUsername;
        }

        public Faculty(string pFacultyName, string pDirector)
        {
            m_FacultyName = pFacultyName;
            string tempDirector = pDirector;
            for(int i = 0; i < Program.PDList.Count; i++)
            {
                if(Program.PDList[i].GetUsername == tempDirector)
                {
                    m_FacultyDirector = Program.PDList[i];
                }
            }
        }
        public Faculty(string pFacultyName, ProgrammeDirector pDirector)
        {
            m_FacultyName = pFacultyName;
            m_FacultyDirector = pDirector;
        }
    }

    //Class for module
    public class Module
    {
        #region Member Variables
        private List<Assessment> assessmentList = new List<Assessment>();
        private string m_ModuleName;
        private string m_ModuleCode;
        private int m_StudentCount;
        private ModuleManager m_ModuleManager; //set to actual module manager
        private string m_ModuleManagerStr; //Can't save object in text
        private Faculty m_Faculty;
        private string m_FacultyStr;
        #endregion

        #region Get variables

        public string GetAllModDetails
        {
            get { return m_ModuleName + "," + m_ModuleCode + "," + m_StudentCount.ToString() + "," + m_ModuleManagerStr + "," + m_FacultyStr; }
        }
        public List<Assessment> GetAssessmentList
        {
            get { return assessmentList; }
        }
        public string GetModuleName
        {
            get { return m_ModuleName; }
        }
        public string GetModuleCode
        {
            get { return m_ModuleCode; }
        }
        public int GetStudentCount
        {
            get { return m_StudentCount; }
        }

        public string GetFaculty
        {
            get { return m_FacultyStr; }
        }
        #endregion

        #region Set variables
        public bool SetModuleName(string pModuleName)
        {
            m_ModuleName = pModuleName;
            return true;
        }
        public bool SetModuleCode(string pModuleCode)
        {
            m_ModuleCode = pModuleCode;
            return true;
        }
        public bool SetStudentCount(int pStudentCount)
        {
            m_StudentCount = pStudentCount;
            return true;
        }

        public bool AddToAssessList(Assessment pAssessment)
        {
            assessmentList.Add(pAssessment);
            return true;
        }
        #endregion

        public override string ToString()
        {
            return m_ModuleCode;
        }

        public Module(string pModuleName, string pModuleCode, int pStudentCount, string pModuleManager, string pFaculty)
        {
            this.m_ModuleName = pModuleName;
            this.m_ModuleCode = pModuleCode;
            this.m_StudentCount = pStudentCount;
            this.m_ModuleManagerStr = pModuleManager;
            this.m_FacultyStr = pFaculty;
        }
    }

    //Class for assessment
    public class Assessment
    {
        #region Member variables
        private string m_AssessmentCode;
        private string m_AssessmentName;
        private string m_AssessmentType;
        private string m_ModuleName;
        private string m_ModuleCode;
        private int m_PercentageGrade; //Percentage grade of module
        private int m_NumOfStudents; //Number of students per module
        private string m_Session; //17/18S1
        private DateTime m_ReleaseDate;
        private DateTime m_SubmissionDate;
        private DateTime m_ExtensionDate;
        private DateTime m_FeedbackDate;
        private bool m_Checked;
        private string uploadedFilePath;
        #endregion

        #region Get variables

        public string GetAllDetails
        {
            get { return m_AssessmentCode + "," + m_AssessmentName + "," + m_AssessmentType + "," + m_ModuleName + "," + m_ModuleCode + "," + m_PercentageGrade + "," + m_NumOfStudents + "," + m_Session + "," + m_ReleaseDate.ToString("dd/MM/yyyy") + "," + m_SubmissionDate.ToString("dd/MM/yyyy") + "," + m_ExtensionDate.ToString("dd/MM/yyyy") + "," + m_FeedbackDate.ToString("dd/MM/yyyy") + "," + m_Checked.ToString() + "," + uploadedFilePath; }
        }
        public string GetAssessmentCode
        {
            get { return m_AssessmentCode; }
        }
        public string GetAssessmentName
        {
            get { return m_AssessmentName; }
        }
        public string GetAssessmentType
        {
            get { return m_AssessmentType; }
        }
        public string GetModuleName
        {
            get { return m_ModuleName; }
        }
        public string GetModuleCode
        {
            get { return m_ModuleCode; }
        }
        public int GetPercentageGrade
        {
            get { return m_PercentageGrade; }
        }
        public int GetNumOfStudents
        {
            get { return m_NumOfStudents; }
        }
        public string GetSession
        {
            get { return m_Session; }
        }
        public DateTime GetReleaseDate
        {
            get { return m_ReleaseDate; }
        }
        public DateTime GetSubmissionDate
        {
            get { return m_SubmissionDate; }
        }
        public DateTime GetExtensionDate
        {
            get { return m_ExtensionDate; }
        }
        public DateTime GetFeedbackDate
        {
            get { return m_FeedbackDate; }
        }
        public bool GetChecked
        {
            get { return m_Checked; }
        }
        public string GetFilePath
        {
            get { return uploadedFilePath; }
        }
        #endregion

        #region Set variables
        public bool SetAssessmentCode(string pAssessmentCode)
        {
            m_AssessmentCode = pAssessmentCode;
            return true;
        }
        public bool SetAssessmentName(string pAssessmentName)
        {
            m_AssessmentName = pAssessmentName;
            return true;
        }
        public bool SetAssessmentType(string pAssessmentType)
        {
            m_AssessmentType = pAssessmentType;
            return true;
        }
        public bool SetModuleName(string pModuleName)
        {
            m_ModuleName = pModuleName;
            return true;
        }
        public bool SetModuleCode(string pModuleCode)
        {
            m_ModuleCode = pModuleCode;
            return true;
        }
        public bool SetPercentageGrade(int pPercentageGrade)
        {
            m_PercentageGrade = pPercentageGrade;
            return true;
        }
        public bool SetNumOfStudents(int pNumOfStudents)
        {
            m_NumOfStudents = pNumOfStudents;
            return true;
        }
        public bool SetSession(string pSession)
        {
            m_Session = pSession;
            return true;
        }
        public bool SetReleaseDate(DateTime pReleaseDate)
        {
            m_ReleaseDate = pReleaseDate;
            return true;
        }
        public bool SetSubmissionDate(DateTime pSubmissionDate)
        {
            m_SubmissionDate = pSubmissionDate;
            return true;
        }
        public bool SetExtensionDate(DateTime pExtensionDate)
        {
            m_ExtensionDate = pExtensionDate;
            return true;
        }
        public bool SetFeedbackDate(DateTime pFeedbackDate)
        {
            m_FeedbackDate = pFeedbackDate;
            return true;
        }
        public bool SetChecked(bool pChecked)
        {
            m_Checked = pChecked;
            return true;
        }
        #endregion

        public Assessment(string pAssesscode, string pAssessName, string pAssessType, string pModName, string pModCode, int pPerGrade, int pNumStu, string pSession, DateTime pRelDate, DateTime pSubDate, DateTime pExDate, DateTime pFeedDate, bool pChecked, string pUploadedFilePath)
        {
            this.m_AssessmentCode = pAssesscode;
            this.m_AssessmentName = pAssessName;
            this.m_AssessmentType = pAssessType;
            this.m_ModuleName = pModName;
            this.m_ModuleCode = pModCode;
            this.m_PercentageGrade = pPerGrade;
            this.m_NumOfStudents = pNumStu;
            this.m_Session = pSession;
            this.m_ReleaseDate = pRelDate;
            this.m_SubmissionDate = pSubDate;
            this.m_ExtensionDate = pExDate;
            this.m_FeedbackDate = pFeedDate;
            this.m_Checked = pChecked;
            this.uploadedFilePath = pUploadedFilePath;
        }

        public override string ToString()
        {
            return m_ModuleCode + " " + m_AssessmentName;
        }
    }

    public class CheckedAssessment : Assessment
    {
        private string m_AssessmentSetter;
        private string m_InternalReviewer;
        private List<int> m_Qs;
        private string m_Comments;
        private int m_Approved;
        private DateTime m_ApprovedDate;
        private bool m_AmmendNeeded;
        private string m_Ammendments = "";

        public bool AddAmmendText(string pAmmendText)
        {
            m_Ammendments = pAmmendText;
            return true;
        }

        public List<int> GetIntList
        {
            get { return m_Qs; }
        }
        public string GetSetterName
        {
            get { return m_AssessmentSetter; }
        }
        public string GetInternalReviewer
        {
            get { return m_InternalReviewer; }
        }
        public string GetComments
        {
            get { return m_Comments; }
        }
        public int GetApprovedStatus
        {
            get { return m_Approved; }
        }
        public string GetAmmendments
        {
            get { return m_Ammendments; }
        }

        public string GetAllCheckedDetails()
        {
            string details = this.GetAllDetails;
            details = details.Replace(',', '*');
            details += "*" +  m_AssessmentSetter + "*";
            details += m_InternalReviewer + "*";
            for(int i = 0; i < m_Qs.Count; i++)
            {
                details += m_Qs[i] + "*";
            }
            details += m_Comments + "*";
            details += m_Approved.ToString() + "*";
            details += m_ApprovedDate.ToString("dd/MM/yyy") + "*";
            details += m_AmmendNeeded.ToString() + "*";
            details += m_Ammendments;
            return details;
        }

        public CheckedAssessment(string pAssesscode, string pAssessName, string pAssessType, string pModName, string pModCode, int pPerGrade, int pNumStu, string pSession, DateTime pRelDate, DateTime pSubDate, DateTime pExDate, DateTime pFeedDate, bool pChecked,string pUploadedFilePath,
        string pAssessSetter, string pInternalReviewer, List<int> pQs, string pComments, int pApproved, DateTime pApprovedDate, bool pAmmendNeeded, string pAmmendments)

        : base(pAssesscode, pAssessName, pAssessType, pModName, pModCode, pPerGrade, pNumStu, pSession, pRelDate, pSubDate, pExDate, pFeedDate, pChecked, pUploadedFilePath)
        {
            this.m_AssessmentSetter = pAssessSetter;
            this.m_InternalReviewer = pInternalReviewer;
            this.m_Qs = pQs;
            this.m_Comments = pComments;
            this.m_Approved = pApproved;
            this.m_ApprovedDate = pApprovedDate;
            this.m_AmmendNeeded = pAmmendNeeded;
            this.m_Ammendments = pAmmendments;
        }
    }
}
