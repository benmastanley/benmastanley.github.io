﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course_Work_Management
{
    public partial class CourseworkSchedule : Form
    {
        private ModuleManager m_Manager = null;
        private Faculty m_Faculty = null;
        private List<DateTime> dates = null;

        public CourseworkSchedule()
        {
            InitializeComponent();
            GetFaculties();
            GetDates();
            CreatePanel();
        }

        public CourseworkSchedule(ModuleManager pManager) : this()
        {
            m_Manager = pManager;
        }

        private void GetFaculties()
        {
            for(int i = 0; i< Program.facultyList.Count; i++)
            {
                facultyCombo.Items.Add(Program.facultyList[i]);
            }
        }

        private void GetDates()
        {
            List<DateTime> allDates = new List<DateTime>();
            DateTime startingDate = new DateTime(2018, 9, 24);
            DateTime endingDate = new DateTime(2019, 9, 20);

            for (DateTime date = startingDate; date <= endingDate; date = date.AddDays(1))
            {
                allDates.Add(date);
            }

            dates = new List<DateTime>();
            int count = 0;
            for (int i = 0; i < allDates.Count; i++)
            {
                if (count < 5)
                {
                    dates.Add(allDates[i]);
                    count++;
                }
                else
                {
                    i++;
                    count = 0;
                }
            }
        }

        //Wipes the panel and redraws basic table
        private void CreatePanel()
        {
            //datePanel.ColumnCount = 0;
            //datePanel.RowCount = 2;
            //int counter = 1;
            //int weekCounter = 5;
            ////For adding all the dates
            //for (int i = 0; i < dates.Count; i++)
            //{
            //    datePanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 60));
            //    datePanel.Controls.Add(new Label() { Text = weekCounter.ToString() }, i, 0);
            //    datePanel.Controls.Add(new Label() { Text = dates[i].ToString("dd/MM/yy") }, i, 1);
            //    if (counter == 5)
            //    {
            //        counter = 1;
            //        if(weekCounter == 52)
            //        {
            //            weekCounter = 1;
            //        }
            //        else
            //        {
            //            weekCounter++;
            //        }
            //    }
            //    else
            //    {
            //        counter++;
            //    }
            //}
            DrawDates();
            usersPanel.RowCount = 1;
            usersPanel.Controls.Add(new Label() { Text = "More Info" }, 0, usersPanel.RowCount - 1);
            usersPanel.Controls.Add(new Label() { Text = "Assessment Name" }, 1, usersPanel.RowCount - 1);
            usersPanel.Controls.Add(new Label() { Text = "Module Code" }, 2, usersPanel.RowCount - 1);
        }

        private void DrawDates()
        {
            datePanel.ColumnCount = 0;
            datePanel.RowCount = 2;
            int counter = 1;
            int weekCounter = 5;
            //For adding all the dates
            for (int i = 0; i < dates.Count; i++)
            {
                datePanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 60));
                datePanel.Controls.Add(new Label() { Text = weekCounter.ToString() }, i, 0);
                datePanel.Controls.Add(new Label() { Text = dates[i].ToString("dd/MM/yy") }, i, 1);
                if (counter == 5)
                {
                    counter = 1;
                    if (weekCounter == 52)
                    {
                        weekCounter = 1;
                    }
                    else
                    {
                        weekCounter++;
                    }
                }
                else
                {
                    counter++;
                }
            }
        }

        private void loadSchedule()
        {

            //datePanel.RowCount = 0;
            //datePanel.Controls.Clear();

            usersPanel.RowCount = 0;
            for (int i = usersPanel.Controls.Count - 1; i >= 0; --i)
            {
                usersPanel.Controls[i].Dispose();
            }
            usersPanel.Controls.Clear();

            usersPanel.Controls.Add(new Label() { Text = "More Info" }, 0, usersPanel.RowCount - 1);
            usersPanel.Controls.Add(new Label() { Text = "Assessment Name" }, 1, usersPanel.RowCount - 1);
            usersPanel.Controls.Add(new Label() { Text = "Module Code" }, 2, usersPanel.RowCount - 1);

            List<Module> modList = new List<Module>();
            for (int i = 0; i < Program.moduleList.Count; i++)
            {
                if (Program.moduleList[i].GetFaculty == m_Faculty.GetFacultyName)
                {
                    modList.Add(Program.moduleList[i]);
                }
            }

            List<Assessment> assessList = new List<Assessment>();
            for (int i = 0; i < modList.Count; i++)
            {
                for (int j = 0; j < Program.assessList.Count; j++)
                {
                    if (modList[i].GetModuleCode == Program.assessList[j].GetModuleCode)
                    {
                        assessList.Add(Program.assessList[j]);
                    }
                }
            }
            for (int j = 0; j < assessList.Count; j++)
            {
                usersPanel.Controls.Add(new Label() { Text = "View" }, 0, usersPanel.RowCount - 1);
                usersPanel.Controls.Add(new Label() { Text = assessList[j].GetAssessmentName }, 1, usersPanel.RowCount - 1);
                usersPanel.Controls.Add(new Label() { Text = assessList[j].GetModuleCode }, 2, usersPanel.RowCount - 1);
                //datePanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 60));
                datePanel.Controls.Add(new Label() { Text = "n/a" }, 0, j + 2);
            }

            for (int i = 0; i < usersPanel.ColumnCount - 1; i++)
            {
                this.usersPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 10));
            }
        }


        private void facultyCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_Faculty = (Faculty)facultyCombo.SelectedItem;
            loadSchedule();
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void datesPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void closeBut_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
