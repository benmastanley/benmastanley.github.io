﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Course_Work_Management;

namespace Course_Work_Management
{
    public partial class CheckerHome : Form
    {
        private ModuleChecker m_ModuleChecker = null;
        private Assessment m_Assessment = null;

        public CheckerHome()
        {
            InitializeComponent();
        }

        public CheckerHome(ModuleChecker pChecker) :this()
        {
            m_ModuleChecker = pChecker;
            logUser.Text = "Logged in as: " + m_ModuleChecker.GetForename + " " + m_ModuleChecker.GetSurname;
            LoadAssessments();
        }


        private void LoadAssessments()
        {
            assessBox.Items.Clear();
            List<Assessment> loadList = m_ModuleChecker.GetAssessToCheck;
            for (int i = 0; i < loadList.Count; i++)
            {
                assessBox.Items.Add(loadList[i]);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void logUser_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            m_Assessment = (Assessment)assessBox.SelectedItem;
            if(m_Assessment == null)
            {
                MessageBox.Show("Please select an assessment before continuing");
            }
            else
            {
                CheckingForm form = new CheckingForm(m_Assessment, m_ModuleChecker);
                form.Show();
                form.FormClosed += new FormClosedEventHandler(Form_Closed);
            }
        }

        private void Form_Closed(object sender, FormClosedEventArgs e)
        {
            LoadAssessments();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            LoadAssessments();
        }
    }
}
