﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class User
    {
        protected string username;
        protected string password;
        protected int age;
        protected string firstName;
        protected string lastName;
        protected string userType;

        public void SetDetails(string username, string password, string firstname, string lastname, int age, string usertype)
        {
            this.username = username;
            this.password = password;
            this.firstName = firstname;
            this.lastName = lastname;
            this.age = age;
            this.userType = usertype;
        }
    }
}
