﻿using System;
using System.Xml;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class UserDataLoad
    {
        public static string LoadUserData(string username, string password, User user)
        {
            XmlDocument xDoc = new XmlDocument();
            string firstname = "", lastname = "", usertype = "";
            int age = 0;
            try { xDoc.Load(@"C:\Users\556546\Documents\group01\ACW\trunk\ACW\ACW\Data\UserData.xml"); }
            catch (Exception e){ return e.Message; }

            XmlNodeList xUserNodeList = xDoc.SelectNodes("/users/user");

            foreach(XmlNode xNode in xUserNodeList)
            {
                if (xNode.SelectSingleNode("username").InnerText == username)
                {
                    if (xNode.SelectSingleNode("password").InnerText == password) // User logged in
                    {
                        foreach(XmlNode node in xNode)
                        {
                            switch(node.Name)
                            {
                                case "firstname":
                                    firstname = node.InnerText;
                                    break;
                                case "lastname":
                                    lastname = node.InnerText;
                                    break;
                                case "age":
                                    age = int.Parse(node.InnerText);
                                    break;
                                case "usertype":
                                    usertype = node.InnerText;
                                    break;
                                default:
                                    break;
                            }
                        }
                        user.SetDetails(username, password, firstname, lastname, age, usertype);
                        return $"User '{username}' logged in\nFirstname => {firstname}\nLastname => {lastname}\nAge => {age}\nUsertype => {usertype}";
                    }
                }
            }
            return "Login Failed";
        }
    }
}
