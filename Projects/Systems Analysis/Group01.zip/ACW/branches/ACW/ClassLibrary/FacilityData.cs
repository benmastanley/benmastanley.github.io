﻿using System;
using System.IO;
using System.Diagnostics;
using System.Xml;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class FacilityData
    {
        private static string docPath = @"FacilityData.xml";
        private static string textDocPath = @"Bookings.txt";
        private static XmlDocument xDoc = new XmlDocument();
        private static List<string> recordList = new List<string>();
        private static int currentIndex = 0;

        public static string LoadDocument()
        {
            try { xDoc.Load(docPath); }
            catch (Exception e) { return e.Message; }
            return "";
        }
        private static void WriteToTextFile(string personalTrainerName, string memberName, string date, string facilityName, string tempTime)
        {
            Debug.WriteLine(personalTrainerName + "-" + memberName + "-" + date + "-" + facilityName + "-" + tempTime + ";");
            string toWrite = personalTrainerName + "-" + memberName + "-" + date + "-" + facilityName + "-" + tempTime + ";";

            if (!recordList.Contains(toWrite))
            {
                recordList.Add(toWrite);
            }
            
            using (StreamWriter sr = new StreamWriter(textDocPath, true))
            {
                sr.WriteLine(recordList[currentIndex]);//sr.WriteLine(string.Join("\n", recordList));
                
                sr.Close();
            }

            currentIndex += 1;

            Debug.WriteLine("Write Successful");
        }
        public static string ReadTextFile()
        {
            string result = "";

            using (StreamReader sr = new StreamReader(textDocPath))
            {
                result = sr.ReadToEnd();
            }

            return result;
        }
        public static string CreateFacility(Facility toCreate, User user = null, string trainee = null)
        {
            string docError = LoadDocument();
            
            if (docError != "")
            {
                return docError;
            }
            
            XmlNode root = xDoc.DocumentElement;
            
            foreach (XmlNode node in root.SelectNodes("facility"))
            {
                if (node.Attributes[0] != null)
                {
                    if (node.Attributes[0].Value == toCreate.name)
                    {
                        return "Facility already exists!";
                    }
                }    
            }

            XmlElement facilityElement = xDoc.CreateElement("facility");

            root.AppendChild(facilityElement);
            facilityElement.SetAttribute("name", toCreate.name);

            foreach(Day day in toCreate.days)
            {
                string[] array = day.name.Split(' ');
                XmlElement dayElement = xDoc.CreateElement(array[0]);
                dayElement.SetAttribute("date", array[1]);
                facilityElement.AppendChild(dayElement);

                var tempDate = array[1];

                foreach(Time time in day.time)
                {
                    string[] tArray = time.time.Split(':');
                    XmlElement timeElement = xDoc.CreateElement("T"+tArray[0]);
                    var tempTime = tArray[0];
                    timeElement.SetAttribute("user", "");
                    if (time.occupied == true)
                    {
                        timeElement.SetAttribute("status", "occupied");
                        if (user != null)
                        {
                            timeElement.SetAttribute("user", user.RetrieveDetails("name"));
                            WriteToTextFile(user.RetrieveDetails("name"), trainee, tempDate, toCreate.name, tempTime);
                        }
                        if (trainee != null)
                        {
                            timeElement.SetAttribute("trainee", trainee);
                        }
                    }
                    else
                    {
                        timeElement.SetAttribute("status", "");
                        timeElement.SetAttribute("trainee", "");
                    }

                    dayElement.AppendChild(timeElement);
                }
            }

            xDoc.Save(docPath);

            return "";
        }
        public static string UpdateFacility(Facility toUpdate, User user, string selectedUserName = null)
        {
            string docError = LoadDocument();

            if (docError != "")
            {
                return docError;
            }

            XmlNode root = xDoc.DocumentElement;

            foreach (XmlNode node in root.SelectNodes("facility"))
            {
                if (node.Attributes[0] != null)
                {
                    if (node.Attributes[0].Value == toUpdate.name)
                    {
                        root.RemoveChild(node);
                    }
                }
            }

            xDoc.Save(docPath);

            CreateFacility(toUpdate, user, selectedUserName);

            return "";
        }
        public static string LoadSessions(Facility toLoad)
        {
            string docError = LoadDocument();

            if (docError != "")
            {
                return docError;
            }
            
            XmlNode root = xDoc.DocumentElement;
            List<string> timesOccupied = new List<string>();

            foreach (XmlNode node in root.SelectNodes("facility"))
            {
                if (node.Attributes[0] != null)
                {
                    if (!(node.Attributes[0].Value == toLoad.name))
                    {
                        return "Incorrect facility";
                    }
                    else
                    {
                        foreach(XmlNode dayNodes in node)
                        {
                            foreach(XmlNode timeNode in dayNodes)
                            {
                                if (timeNode.Attributes["status"].Value == "occupied") // VERY IMPORTANT BELOW DO NOT CHANGE
                                {
                                    timesOccupied.Add(dayNodes.Name + " "+ dayNodes.Attributes["date"].Value + " " + timeNode.Name.Substring(1, timeNode.Name.Length - 1) + ":00");
                                }
                            }
                        }
                    }
                }
            }
            
            foreach (string s in timesOccupied)
            {
                string[] array = s.Split(' ');
                foreach(Day day in toLoad.days)
                {
                    if (day.ToString() == array[0] + " " + array[1])
                    {
                        foreach(Time time in day.time)
                        {
                            if (time.time == array[2])
                            {
                                time.occupied = true;
                            }
                        }
                    }
                }
            }

            return "";
        }
    }
}
