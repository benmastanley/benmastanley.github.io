﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class User
    {
        protected int age;
        protected string email;
        protected string username;
        protected string password;
        protected string firstname;
        protected string lastname;
        protected string usertype;
        protected string active;

        public void SetDetails(string username, string password, string firstname, string lastname, int age, string usertype, string email, string active = "false")
        {
            this.username = username;
            this.password = password;
            this.firstname = firstname;
            this.lastname = lastname;
            this.age = age;
            this.usertype = usertype;
            this.email = email;
            this.active = active;
        }
        
        public string RetrieveDetails(string detail = "all")
        {
            string details = "";
            detail = detail.ToLower();

            switch(detail)
            {
                case "all":
                    details = $"User '{username}' logged in\nEmail => {email}\nFirstname => {firstname}\nLastname => {lastname}\nAge => {age}\nUsertype => {usertype}\nActive => {active}";
                    break;
                case "email":
                    details = email;
                    break;
                case "username":
                    details = username;
                    break;
                case "password":
                    details = password;
                    break;
                case "firstname":
                    details = firstname;
                    break;
                case "lastname":
                    details = lastname;
                    break;
                case "name":
                    details = firstname + " " + lastname;
                    break;
                case "age":
                    details = age.ToString();
                    break;
                case "usertype":
                    details = usertype;
                    break;
                case "active":
                    details = active;
                    break;
                default:
                    break;
            }

            return details;
        }

        public override string ToString()
        {
            return username;
        }
    }
}
