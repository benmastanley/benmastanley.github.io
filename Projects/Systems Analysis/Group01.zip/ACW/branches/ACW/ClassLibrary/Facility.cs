﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Facility
    {
        public string name { get; set; }
        public List<Day> days = new List<Day>();
        
        public Facility(string name)
        {
            this.name = name;

            DateTime today = DateTime.Today;
            for(int i = 0; i < 7; i++)
            {
                string[] array = today.AddDays(i).Date.ToShortDateString().Split('/');
                string temp = array[0];
                array[0] = array[1];
                array[1] = temp;
                days.Add(new Day($"{today.AddDays(i).DayOfWeek} {string.Join("/", array)}"));
            }
        }
        public override string ToString()
        {
            return name;
        }
    }
}
