﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Time
    {
        public string time { get; set; }
        public bool occupied { get; set; }
        public User userOccupied { get; set; }

        public Time (string time)
        {
            this.time = time;
            this.occupied = false;
        }

        public override string ToString()
        {
            if (occupied == false)
            {
                return time;
            }
            else
            {
                return time + " occupied";
            }
        }
    }
}
