﻿using System;
using System.Xml;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Resources;
using System.Reflection;

namespace ClassLibrary
{
    public static class UserData
    {
        // Create a resource manager to retrieve resources.


        private static string docPath = @"UserData.xml";
        private static XmlDocument xDoc = new XmlDocument();

        public static string LoadDocument()
        {
            try { xDoc.Load(docPath); }
            catch (Exception e) { return e.Message; }
            return "";
        }

        public static string SaveUserData(User user)
        {
            string docError = LoadDocument();

            if (docError != "")
            {
                return docError;
            }

            // Creates user, saves document and reloads it
            CreateUser(user);
            xDoc.Save(docPath);
            LoadDocument();

            return "UserSaved!";
        }

        public static string LoadUserData(string username, string password, User user) // Checks input data against xml database
        {
            string docError = LoadDocument();

            if (docError != "")
            {
                return docError;
            }

            string error = ValidateCredentials(username, password);

            if (error.Length > 0)
            {
                return error;
            }

            // Document loading and validation done

            string email = "", firstname = "", lastname = "", usertype = "", active = "";
            int age = 0;

            XmlNodeList xUserNodeList = xDoc.SelectNodes("/users/user");

            foreach (XmlNode xNode in xUserNodeList)
                {
                    if (xNode.SelectSingleNode("username").InnerText == username)
                    {
                        if (xNode.SelectSingleNode("password").InnerText == password) // User logged in
                        {
                            foreach (XmlNode node in xNode)
                            {
                                Debug.WriteLine(node.Name);
                                switch (node.Name) // Checks user node contents
                                {
                                    case "firstname":
                                        firstname = node.InnerText;
                                        break;
                                    case "lastname":
                                        lastname = node.InnerText;
                                        break;
                                    case "age":
                                        age = int.Parse(node.InnerText);
                                        break;
                                    case "usertype":
                                        usertype = node.InnerText;
                                        break;
                                    case "email":
                                        email = node.InnerText;
                                        break;
                                    case "active":
                                        active = node.InnerText;
                                        break;
                                    default:
                                        break;
                                }
                            }
                            user.SetDetails(username, password, firstname, lastname, age, usertype, email, active);
                            return "1"; // Login success
                        }
                    }
                }
            
            return "0"; // Login Failed
        }
        
        public static Task<string> SetUserData(User user, string toChange, string value)
        {
            string docError = LoadDocument();
            
            if (docError != "")
            {
                return Task.FromResult(string.Empty);
            }

            
            XmlNodeList xUserNodeList = xDoc.SelectNodes("/users/user");

            foreach (XmlNode xNode in xUserNodeList)
            {
                if (xNode.SelectSingleNode("email").InnerText == user.RetrieveDetails("email"))
                {
                    if (xNode.SelectSingleNode(toChange) != null)
                    {
                        xNode.SelectSingleNode(toChange).InnerText = value;
                        break;
                    }
                }
            }

            xDoc.Save(docPath);
            LoadDocument();
            return Task.FromResult(string.Empty);
        }

        public static List<User> LoadAllUsers()
        {
            string docError = LoadDocument();

            if (docError != "")
            {
                return null;
            }

            string username = "", email = "", firstname = "", lastname = "", usertype = "", active = "";
            int age = 0;

            XmlNodeList xUserNodeList = xDoc.SelectNodes("/users/user");

            List<User> userList = new List<User>();

            for (int i = 0; i < xDoc.DocumentElement.ChildNodes.Count; i++)
            {
                if (xDoc.DocumentElement.ChildNodes[i].SelectSingleNode("username") != null)
                {
                    username = xDoc.DocumentElement.ChildNodes[i].SelectSingleNode("username").InnerText;
                }
                if (xDoc.DocumentElement.ChildNodes[i].SelectSingleNode("firstname") != null)
                {
                    firstname = xDoc.DocumentElement.ChildNodes[i].SelectSingleNode("firstname").InnerText;
                }
                if (xDoc.DocumentElement.ChildNodes[i].SelectSingleNode("lastname") != null)
                {
                    lastname = xDoc.DocumentElement.ChildNodes[i].SelectSingleNode("lastname").InnerText;
                }
                if (xDoc.DocumentElement.ChildNodes[i].SelectSingleNode("age") != null)
                {
                    age = int.Parse(xDoc.DocumentElement.ChildNodes[i].SelectSingleNode("age").InnerText);
                }
                if (xDoc.DocumentElement.ChildNodes[i].SelectSingleNode("usertype") != null)
                {
                    usertype = xDoc.DocumentElement.ChildNodes[i].SelectSingleNode("usertype").InnerText;
                }
                if (xDoc.DocumentElement.ChildNodes[i].SelectSingleNode("email") != null)
                {
                    email = xDoc.DocumentElement.ChildNodes[i].SelectSingleNode("email").InnerText;
                }
                if (xDoc.DocumentElement.ChildNodes[i].SelectSingleNode("active") != null)
                {
                    active = xDoc.DocumentElement.ChildNodes[i].SelectSingleNode("active").InnerText;
                }
                User newUser = new User();
                newUser.SetDetails(username, "", firstname, lastname, age, usertype, email, active);
                userList.Add(newUser);
            }
            
            return userList;
        }

        private static string ValidateCredentials(string username, string password) // User credential validation
        {
            string error = "";

            if (username.Length == 0)
            {
                error += "- username cannot be empty!\n";
            }
            if (password.Length == 0)
            {
                error += "- password cannot be empty!\n";
            }

            return error;
        }

        public static string CreateUser(User user) // Change if any extra user variables added
        {
            
            string docError = LoadDocument();

            if (docError != "")
            {
                return null;
            }
            
            string email = user.RetrieveDetails("email");

            XmlNodeList xUserNodeList = xDoc.SelectNodes("/users/user");

            foreach (XmlNode xNode in xUserNodeList)
            {
                if (xNode.SelectSingleNode("email").InnerText == email) // if email already exists
                {
                    return "User email already exists!";
                }
            }
            
            // Elements
            XmlElement root = xDoc.DocumentElement;
            XmlElement userElement = xDoc.CreateElement("user");
            XmlElement usernameElement = xDoc.CreateElement("username");
            XmlElement passwordElement = xDoc.CreateElement("password");
            XmlElement firstnameElement = xDoc.CreateElement("firstname");
            XmlElement lastnameElement = xDoc.CreateElement("lastname");
            XmlElement ageElement = xDoc.CreateElement("age");
            XmlElement usertypeElement = xDoc.CreateElement("usertype");
            XmlElement emailElement = xDoc.CreateElement("email");
            XmlElement activeElement = xDoc.CreateElement("active");

            // Setting
            usernameElement.InnerText = user.RetrieveDetails("username");
            passwordElement.InnerText = user.RetrieveDetails("password");
            firstnameElement.InnerText = user.RetrieveDetails("firstname");
            lastnameElement.InnerText = user.RetrieveDetails("lastname");
            ageElement.InnerText = user.RetrieveDetails("age").ToString();
            usertypeElement.InnerText = user.RetrieveDetails("usertype");
            emailElement.InnerText = user.RetrieveDetails("email");
            activeElement.InnerText = user.RetrieveDetails("active");

            // Appending
            root.AppendChild(userElement);
            userElement.AppendChild(usernameElement);
            userElement.AppendChild(passwordElement);
            userElement.AppendChild(firstnameElement);
            userElement.AppendChild(lastnameElement);
            userElement.AppendChild(ageElement);
            userElement.AppendChild(usertypeElement);
            userElement.AppendChild(emailElement);
            userElement.AppendChild(activeElement);

            xDoc.Save(docPath);
            LoadDocument();

            return "";
        }
    }
}
