﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class Day
    {
        public string name { get; set; }
        public List<Time> time = new List<Time>();

        public Day(string name)
        {
            this.name = name;
            for(int i = 0; i <= 12; i++)
            {
                time.Add(new Time($"{(i + 8).ToString()}:00"));
            }
        }
        public override string ToString()
        {
            return this.name;
        }
    }
}
