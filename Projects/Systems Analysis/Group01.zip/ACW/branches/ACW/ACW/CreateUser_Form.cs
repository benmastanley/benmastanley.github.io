﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using ClassLibrary;

namespace ACW
{
    public partial class CreateUser_Form : Form
    {
        User selectedUser, user;
        int selectedIndex = -1;
        public static UserCreationInputForm userCreation;
        
        public CreateUser_Form(User currentUser)
        {
            InitializeComponent();
            
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Manage Members"; 
            HideElements();
            user = currentUser;
            RefreshUsers(user);
        }

        private void ShowElements()
        {
            label2.Visible = true;
            label3.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            label6.Visible = true;
            label7.Visible = true;
            firstNameLabel.Visible = true;
            lastNameLabel.Visible = true;
            ageLabel.Visible = true;
            emailLabel.Visible = true;
            userTypeLabel.Visible = true;
            activeButton.Enabled = true;
            activeButton.Visible = true;
        }

        private void HideElements()
        {
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            firstNameLabel.Visible = false;
            lastNameLabel.Visible = false;
            ageLabel.Visible = false;
            emailLabel.Visible = false;
            userTypeLabel.Visible = false;
            activeButton.Enabled = false;
            activeButton.Visible = false;
        }

        private void RefreshUsers(User currentUser)
        {
            userApplicationBox.Items.Clear();
            // Loads users
            List<User> userList = UserData.LoadAllUsers();

            foreach (User user in userList)
            {
                if (user.RetrieveDetails("username") != currentUser.RetrieveDetails("username")) // Shows all users except current user
                {
                    userApplicationBox.Items.Add(user);
                }
            }
        }

        private void RefreshForm(User selectedUser = null)
        {
            
            firstNameLabel.Text = selectedUser.RetrieveDetails("firstname");

            lastNameLabel.Text = selectedUser.RetrieveDetails("lastname");

            ageLabel.Text = selectedUser.RetrieveDetails("age");

            emailLabel.Text = selectedUser.RetrieveDetails("email");

            userTypeLabel.Text = selectedUser.RetrieveDetails("usertype");
            switch (userTypeLabel.Text)
            {
                case "Administrator":
                    userTypeLabel.ForeColor = Color.Blue;
                    break;
                case "Standard":
                    userTypeLabel.ForeColor = Color.LightGreen;
                    break;
                case "Personal Trainer":
                    userTypeLabel.ForeColor = Color.Gold;
                    break;
                default:
                    break;
            }
            if (selectedUser.RetrieveDetails("active") == "false")
            {
                activeButton.BackColor = Color.Silver;
                activeButton.Text = "Inactive";
            }
            else if (selectedUser.RetrieveDetails("active") == "true")
            {
                activeButton.BackColor = Color.LawnGreen;
                activeButton.Text = "Active";
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void CreateUser_Form_Load(object sender, EventArgs e)
        {

        }

        private void userApplicationBox_SelectedIndexChanged(object sender, EventArgs e) // Setting object values to UI
        {
            selectedUser = (User)userApplicationBox.SelectedItem;
            
            RefreshForm(selectedUser);
            ShowElements();
        }

        private async void activeButton_Click(object sender, EventArgs e)
        {
            selectedIndex = userApplicationBox.SelectedIndex;
            if (activeButton.Text == "Active")
            {
                DialogResult dialogResult = MessageBox.Show("This will disable user membership, are you sure?", "Set User to Inactive", MessageBoxButtons.OKCancel);
                if (dialogResult == DialogResult.OK)
                {
                    Task<string> awaitData = UserData.SetUserData(selectedUser, "active", "false");
                    await awaitData;
                    RefreshUsers(user);
                    RefreshForm(selectedUser);
                    this.Hide();
                    this.Show();
                    HideElements();
                }
            }
            else if (activeButton.Text == "Inactive")
            {
                DialogResult dialogResult = MessageBox.Show("This will enable user membership, are you sure?", "Set User to Active", MessageBoxButtons.OKCancel);
                if (dialogResult == DialogResult.OK)
                {
                    Task<string> awaitData = UserData.SetUserData(selectedUser, "active", "true");
                    await awaitData;
                    RefreshUsers(user);
                    RefreshForm(selectedUser);
                    this.Hide();
                    this.Show();
                    HideElements();
                }
            }
            if (selectedIndex >= 0)
            {
                userApplicationBox.SelectedItem = userApplicationBox.Items[selectedIndex];
            }
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            Form1.standardUserForm.Show();
        }
    }
}
