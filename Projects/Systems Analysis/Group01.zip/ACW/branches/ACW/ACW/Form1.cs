﻿using System;
using System.Diagnostics;
using System.Xml;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary;

namespace ACW
{
    public partial class Form1 : Form
    {
        // Setting forms
        public static Standard_User_Main standardUserForm;
        public static UserCreationInputForm userCreate;
        public static Form1 loginForm;

        // Setting user
        User user = new User();

        public Form1()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Gym-X | User Login";
            loginForm = this;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void usernameBox_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            
        }

        private void passwordBox_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string userLoadOutput = UserData.LoadUserData(usernameBox.Text, passwordBox.Text, user);
            
            if (userLoadOutput == "1" || userLoadOutput == "0")
            {
                if (userLoadOutput == "1") // Login success
                {
                    //MessageBox.Show(UserData.SaveUserData(user));
                    this.Hide();
                    standardUserForm = new Standard_User_Main(user);
                    standardUserForm.Text = "Main";
                    MessageBox.Show("Login Succeeded!");
                    Debug.WriteLine(user.RetrieveDetails()); // For debugging purposes
                    standardUserForm.Show();
                }
                else if (userLoadOutput == "0") // Login fail
                {
                    MessageBox.Show("Login Failed!");
                }
            }
            else
            {
                MessageBox.Show(userLoadOutput); // Errors
            }
        }

        private void createUserButton_Click(object sender, EventArgs e)
        {
            userCreate = new UserCreationInputForm(this);
            userCreate.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
