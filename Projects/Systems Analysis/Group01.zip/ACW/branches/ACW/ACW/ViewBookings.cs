﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary;

namespace ACW
{
    public partial class ViewBookings : Form
    {
        User currentUser;
        public ViewBookings(User user)
        {
            InitializeComponent();
            currentUser = user;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Gym-X | View Bookings";
        }

        private void bookingsBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ViewBookings_Load(object sender, EventArgs e)
        {
            string lines = FacilityData.ReadTextFile();
            string[] lineArray = lines.Split(';');

            foreach(string line in lineArray)
            {
                string[] dataArr = line.Split('-');
                
                if (dataArr.Length == 5)
                {
                    if (dataArr[1] == currentUser.RetrieveDetails("name"))
                    {
                        bookingsBox.Items.Add($"{dataArr[1]}  Date: {dataArr[2]}      Time: {dataArr[4]}:00       Personal Trainer: {dataArr[0]}       Facility: {dataArr[3]}");
                    }
                    if (dataArr[0].Split(' ')[0] == currentUser.RetrieveDetails("firstname") && dataArr[0].Split(' ')[1] == currentUser.RetrieveDetails("lastname"))
                    {
                        bookingsBox.Items.Add($"Date: {dataArr[2]}      Time: {dataArr[4]}:00       Customer: {dataArr[1]}       Facility: {dataArr[3]}");
                    }
                }
            }
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            Form1.standardUserForm.Show();
        }
    }
}
