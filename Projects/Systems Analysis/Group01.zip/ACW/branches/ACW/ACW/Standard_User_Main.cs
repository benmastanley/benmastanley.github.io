﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary;

namespace ACW
{
    public partial class Standard_User_Main : Form
    {
        public static CreateUser_Form createUserForm;
        public static ViewBookings viewBookingsForm;
        public static Timetable_Form timetableForm;
        
        User currentUser;

        private void LoadUserAccessibilities(User user)
        {
            if (user.RetrieveDetails("usertype") == "Administrator")
            {
                createUserButton.Enabled = true;
                createUserButton.Visible = true;
                label2.Visible = false;
                accountTypeValue.Visible = false;
                accountTypeLabel.Text = "Administrator";
                accountTypeLabel.ForeColor = Color.Blue;
            }
            else if (user.RetrieveDetails("usertype") == "Personal Trainer")
            {
                accountTypeLabel.Text = "Personal Trainer";
                accountTypeLabel.ForeColor = Color.Goldenrod;
                
            }
            else if (user.RetrieveDetails("usertype") == "Standard")
            {
                accountTypeLabel.Text = "Standard";
                accountTypeLabel.ForeColor = Color.Green;
                viewBookingsButton.Enabled = true;
                viewBookingsButton.Visible = true;
            }
            if (user.RetrieveDetails("active") == "false")
            {
                accountTypeValue.ForeColor = Color.Red;
                accountTypeValue.Text = "Inactive";
                viewBookingsButton.Enabled = false;
                viewBookingsButton.Visible = false;
            }
            else if (user.RetrieveDetails("active") == "true")
            {
                accountTypeValue.ForeColor = Color.Green;
                accountTypeValue.Text = "Active";
                if (user.RetrieveDetails("usertype") == "Personal Trainer") // Able to book, maybe add admin later
                {
                    timetableButton.Enabled = true;
                    timetableButton.Visible = true;
                    viewBookingsButton.Enabled = true;
                    viewBookingsButton.Visible = true;
                }
                if (user.RetrieveDetails("usertype") == "Standard")
                {
                    viewBookingsButton.Enabled = true;
                    viewBookingsButton.Visible = true;
                }
            }
        }
        public Standard_User_Main(User user)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;

            currentUser = user;

            label1.Text = $"Welcome, {user.RetrieveDetails("name")}!";
            accountTypeValue.Text = user.RetrieveDetails("usertype");

            LoadUserAccessibilities(user);
        }

        private void Standard_User_Main_Load(object sender, EventArgs e)
        {
            this.Text = "Gym-X | Main";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void accountTypeValue_Click(object sender, EventArgs e)
        {

        }
        
        private void createUserButton_Click(object sender, EventArgs e)
        {
            createUserForm = new CreateUser_Form(currentUser);
            this.Hide();
            createUserForm.Name = "Create User";
            createUserForm.Show();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void addMemberButton_Click(object sender, EventArgs e)
        {

        }

        private void timetableButton_Click(object sender, EventArgs e)
        {
            timetableForm = new Timetable_Form(currentUser);
            this.Hide();
            timetableForm.Name = "Timetables";
            timetableForm.Show();
        }

        private void viewBookingsButton_Click(object sender, EventArgs e)
        {
            viewBookingsForm = new ViewBookings(currentUser);
            this.Hide();
            viewBookingsForm.Name = "View Bookings";
            viewBookingsForm.Show();
        }

        private void logOutButton_Click(object sender, EventArgs e)
        {
            Form1.loginForm.Show();
            Form1.standardUserForm.Hide();
        }
    }
}
