﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary;

namespace ACW
{
    public partial class Timetable_Form : Form
    {
        User currentUser;
        List<Facility> facilities = new List<Facility>();
        List<User> userList = UserData.LoadAllUsers();
        List<string> userNames = new List<string>();
        Facility fCourt, tCourt;
        Time selectedTime;

        string selectedUser = "";

        public Timetable_Form(User user)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Gym-X | Bookings";
            currentUser = user;
            UpdateFacilities();
            // Add facilities
            comboBox1.Items.Add(fCourt);
            
            UpdateForm();
            foreach(User u in userList)
            {
                if (u.RetrieveDetails("name") != currentUser.RetrieveDetails("name"))
                {
                    userDropBox.Items.Add(u.RetrieveDetails("name"));
                }
            }
        }

        private void Timetable_Form_Load(object sender, EventArgs e)
        {

        }

        private void UpdateFacilities()
        {
            fCourt = new Facility("Football Court");
            FacilityData.CreateFacility(fCourt, null, selectedUser);
            facilities.Add(fCourt);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            Form1.standardUserForm.Show();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex > -1)
            {
                submitButton.Visible = true;
                submitButton.Enabled = true;
                selectedTime = (Time)listBox1.SelectedItem;
            }
            else
            {
                submitButton.Visible = false;
                submitButton.Enabled = false;
            }
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            string error = ValidateForm();
            if (error.Length == 0) // if no error
            {
                selectedTime.occupied = true;
                selectedTime.userOccupied = currentUser;
                
                    FacilityData.UpdateFacility(fCourt, currentUser, selectedUser); // deal with array here
                UpdateForm();
                MessageBox.Show("Successfully booked!");
            }
            else
            {
                MessageBox.Show(error);
            }
        }

        private void UpdateForm()
        {
            if (dayPicker.SelectedIndex > -1)
            {
                listBox1.Items.Clear();

                ClassLibrary.Day currentDay = (ClassLibrary.Day)dayPicker.SelectedItem;
                for (int i = 0; i < currentDay.time.Count; i++)
                {
                    listBox1.Items.Add(currentDay.time[i]);
                }
            }
        }

        private string ValidateForm()
        {
            string error = "";
            if (comboBox1.SelectedItem == null)
            {
                error += "- Must select an item\n";
            }
            if (comboBox1.SelectedIndex < 0)
            {
                error += "- Must pick a facility\n";
            }
            if (dayPicker.SelectedIndex < 0)
            {
                error += "- Must pick a day\n";
            }
            if (listBox1.SelectedItem.ToString().Contains("occupied") && comboBox1.SelectedItem != null)
            {
                error += "Already booked!\n";
            }
            return error;
        }

        private void dayPicker_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateForm();
        }

        private void userDropBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedUser = userDropBox.SelectedItem.ToString();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.GetType() != typeof(string))
            {
                dayPicker.Items.Clear();

                Facility currentFacility = (Facility)comboBox1.SelectedItem;

                FacilityData.LoadSessions(currentFacility);

                foreach (ClassLibrary.Day day in currentFacility.days)
                {
                    dayPicker.Items.Add(day);
                }
            }
        }
    }
}
