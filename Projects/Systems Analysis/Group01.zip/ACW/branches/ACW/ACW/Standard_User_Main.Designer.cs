﻿namespace ACW
{
    partial class Standard_User_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Standard_User_Main));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.accountTypeValue = new System.Windows.Forms.Label();
            this.createUserButton = new System.Windows.Forms.Button();
            this.timetableButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.accountTypeLabel = new System.Windows.Forms.Label();
            this.viewBookingsButton = new System.Windows.Forms.Button();
            this.logOutButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.label1.Location = new System.Drawing.Point(302, 189);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome user!";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.label2.Location = new System.Drawing.Point(12, 416);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Account Status: ";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // accountTypeValue
            // 
            this.accountTypeValue.AutoSize = true;
            this.accountTypeValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.accountTypeValue.ForeColor = System.Drawing.Color.Green;
            this.accountTypeValue.Location = new System.Drawing.Point(177, 416);
            this.accountTypeValue.Name = "accountTypeValue";
            this.accountTypeValue.Size = new System.Drawing.Size(71, 25);
            this.accountTypeValue.TabIndex = 2;
            this.accountTypeValue.Text = "Active";
            this.accountTypeValue.Click += new System.EventHandler(this.accountTypeValue_Click);
            // 
            // createUserButton
            // 
            this.createUserButton.Enabled = false;
            this.createUserButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.createUserButton.Location = new System.Drawing.Point(17, 80);
            this.createUserButton.Name = "createUserButton";
            this.createUserButton.Size = new System.Drawing.Size(148, 60);
            this.createUserButton.TabIndex = 3;
            this.createUserButton.Text = "Manage Members";
            this.createUserButton.UseVisualStyleBackColor = true;
            this.createUserButton.Visible = false;
            this.createUserButton.Click += new System.EventHandler(this.createUserButton_Click);
            // 
            // timetableButton
            // 
            this.timetableButton.Enabled = false;
            this.timetableButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.timetableButton.Location = new System.Drawing.Point(17, 176);
            this.timetableButton.Name = "timetableButton";
            this.timetableButton.Size = new System.Drawing.Size(148, 54);
            this.timetableButton.TabIndex = 4;
            this.timetableButton.Text = "Book Session";
            this.timetableButton.UseVisualStyleBackColor = true;
            this.timetableButton.Visible = false;
            this.timetableButton.Click += new System.EventHandler(this.timetableButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.label3.Location = new System.Drawing.Point(12, 364);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Account Type: ";
            // 
            // accountTypeLabel
            // 
            this.accountTypeLabel.AutoSize = true;
            this.accountTypeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.accountTypeLabel.ForeColor = System.Drawing.Color.Green;
            this.accountTypeLabel.Location = new System.Drawing.Point(177, 364);
            this.accountTypeLabel.Name = "accountTypeLabel";
            this.accountTypeLabel.Size = new System.Drawing.Size(144, 25);
            this.accountTypeLabel.TabIndex = 6;
            this.accountTypeLabel.Text = "Account Type";
            // 
            // viewBookingsButton
            // 
            this.viewBookingsButton.Enabled = false;
            this.viewBookingsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.viewBookingsButton.Location = new System.Drawing.Point(17, 258);
            this.viewBookingsButton.Name = "viewBookingsButton";
            this.viewBookingsButton.Size = new System.Drawing.Size(148, 54);
            this.viewBookingsButton.TabIndex = 7;
            this.viewBookingsButton.Text = "View Bookings";
            this.viewBookingsButton.UseVisualStyleBackColor = true;
            this.viewBookingsButton.Visible = false;
            this.viewBookingsButton.Click += new System.EventHandler(this.viewBookingsButton_Click);
            // 
            // logOutButton
            // 
            this.logOutButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.logOutButton.Location = new System.Drawing.Point(623, 364);
            this.logOutButton.Name = "logOutButton";
            this.logOutButton.Size = new System.Drawing.Size(148, 54);
            this.logOutButton.TabIndex = 8;
            this.logOutButton.Text = "Log Out";
            this.logOutButton.UseVisualStyleBackColor = true;
            this.logOutButton.Click += new System.EventHandler(this.logOutButton_Click);
            // 
            // Standard_User_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Beige;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.logOutButton);
            this.Controls.Add(this.viewBookingsButton);
            this.Controls.Add(this.accountTypeLabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.timetableButton);
            this.Controls.Add(this.createUserButton);
            this.Controls.Add(this.accountTypeValue);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Standard_User_Main";
            this.Text = "SSS";
            this.Load += new System.EventHandler(this.Standard_User_Main_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label accountTypeValue;
        private System.Windows.Forms.Button createUserButton;
        private System.Windows.Forms.Button timetableButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label accountTypeLabel;
        private System.Windows.Forms.Button viewBookingsButton;
        private System.Windows.Forms.Button logOutButton;
    }
}