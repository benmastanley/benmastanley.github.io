﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using ClassLibrary;

namespace ACW
{
    public partial class UserCreationInputForm : Form
    {
        Form1 form1;
        public UserCreationInputForm(Form1 startForm)
        {
            InitializeComponent();
            form1 = startForm;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Gym-X | Create User";
        }
        
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            form1.Show();
            CreateUser_Form.userCreation = null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string error = ValidateForm();
            if (error.Length > 0) // If errors
            {
                MessageBox.Show(error);
            }
            else
            {
                User newUser = new User();
                newUser.SetDetails(usernameBox.Text, passwordBox.Text, firstNameBox.Text, lastNameBox.Text, int.Parse(ageBox.Text), userTypeBox.Text, emailBox.Text);
                string output = UserData.CreateUser(newUser);
                if (output.Length <= 0) // Checks if email is present in db
                {
                    MessageBox.Show("User successfully created!");
                    this.Close();
                }
                else
                {
                    MessageBox.Show(output);
                }
            }
        }

        private string ValidateForm()
        {
            string error = "";

            if (usernameBox.Text.Length == 0)
            {
                error += "- Username cannot be empty!\n";
            }
            if (passwordBox.Text.Length == 0)
            {
                error += "- Password cannot be empty!\n";
            }
            if (firstNameBox.Text.Length == 0)
            {
                error += "- First name cannot be empty!\n";
            }
            if (lastNameBox.Text.Length == 0)
            {
                error += "- Last name cannot be empty!\n";
            }
            if (ageBox.Text.Length == 0)
            {
                error += "- Age cannot be empty!\n";
            }
            else
            {
                try
                {
                    int age = int.Parse(ageBox.Text);
                    if (!(age >= 14 && age <= 80))
                    {
                        error += "- Input age is out of age limit!\n";
                    }
                }
                catch { error += "- Age must be a number!\n"; }
            }
            if (emailBox.Text.Length == 0)
            {
                error += "- Email cannot be empty!\n";
            }
            else
            {
                Regex regex = new Regex(@"([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)"); // Email pattern
                if (!regex.IsMatch(emailBox.Text))
                {
                    error += "- Email not in correct format!\n";
                }
            }
            if (userTypeBox.SelectedIndex < 0)
            {
                error += "- Please select a user type\n";
            }
            return error;
        }

        private void UserCreationInputForm_Load(object sender, EventArgs e)
        {

        }
    }
}
