package stanley.ben.acw;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public LiveData<ArrayList<String>> puzzleNames;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AcceptSSLCerts.accept();
        //puzzleNames = Repository.getInstance(getApplicationContext()).loadFromJsonIndex();
    }

    public void loadPuzzles(View view){
        Intent playGameIntent = new Intent(getApplicationContext(), ListActivity.class);
        startActivity(playGameIntent);
    }

    public void loadHighScores(View view) {
        Intent viewHighScoresIntent = new Intent(getApplicationContext(), HighScoresActivity.class);
        startActivity(viewHighScoresIntent);
    }

    public void loadAbout(View view) {
        Intent loadAboutIntent = new Intent(getApplicationContext(), aboutActivity.class);
        startActivity(loadAboutIntent);
    }

    public void loadPuzzleList(View view) {
        Intent loadPuzzleListIntent = new Intent(getApplicationContext(), PuzzleListActivity.class);
        startActivity(loadPuzzleListIntent);
    }
}
