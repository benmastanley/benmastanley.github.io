package stanley.ben.acw;

import android.graphics.Bitmap;

public class Puzzle {
    private String mName;
    private String mImage1;
    private String mImage2;
    private Layout mLayout;
    private Bitmap[] mImages;

    public Puzzle(String pName, String pImage1, String pImage2, Layout pLayout){
        setName(pName);
        setImage1(pImage1);
        setImage2(pImage2);
        setLayout(pLayout);
        mImages = new Bitmap[24];
        // setLayout(pPuzzleLayout);
    }
    public String getName() { return mName; }
    public void setName(String pName) { mName = pName; }
    public void setImage1(String pImage1) { mImage1 = pImage1; }
    public void setImage2(String pImage2) { mImage2 = pImage2; }
    public void setLayout(Layout pLayout) { mLayout = pLayout; }
    public void setBitmap(Bitmap pImage, int index) { mImages[index] = pImage; }
}
