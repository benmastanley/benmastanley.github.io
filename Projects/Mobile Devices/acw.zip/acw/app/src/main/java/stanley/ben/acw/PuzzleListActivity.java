package stanley.ben.acw;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class PuzzleListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_puzzle_list_activity);
    }
    public void loadNeckingPuzzle(View view){
        Intent loadGiraffePuzzleIntent = new Intent(getApplicationContext(), LocallySavedPuzzleActivity.class);
        loadGiraffePuzzleIntent.putExtra("puzzleName", "Necking");
        startActivity(loadGiraffePuzzleIntent);
    }
    public void loadTractorPuzzle(View view){
        Intent loadTractorPuzzleIntent = new Intent(getApplicationContext(), LocallySavedPuzzleActivity.class);
        loadTractorPuzzleIntent.putExtra("puzzleName", "Tractor");
        startActivity(loadTractorPuzzleIntent);
    }
    public void loadPipingPuzzle(View view){
        Intent loadPipingPuzzleIntent = new Intent(getApplicationContext(), LocallySavedPuzzleActivity.class);
        loadPipingPuzzleIntent.putExtra("puzzleName", "Piping");
        startActivity(loadPipingPuzzleIntent);
    }
}
