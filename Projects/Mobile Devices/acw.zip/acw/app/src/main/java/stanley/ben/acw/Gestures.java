package stanley.ben.acw;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.GridView;

public class Gestures extends GridView {
    private GestureDetector mGestureDetector;
    private boolean mFling = false;
    private float mTouchX;
    private float mTouchY;
    private static final int minSwipeDistance = 100, maxSwipeOffPath = 100, thresholdVelocity =100;

    public Gestures(Context pContext){
        super(pContext);
        initialise(pContext);
    }
    public Gestures(Context pContext, AttributeSet pAttributeSet){
        super(pContext,  pAttributeSet);
        initialise(pContext);
    }
    public Gestures(Context context, AttributeSet pAttributeSet, int pDefStyAttribute){
        super(context, pAttributeSet, pDefStyAttribute);
        initialise(context);
    }
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public Gestures(Context context, AttributeSet pAttributeSet, int pDefStyAttribute, int pDefStyRes){
        super(context, pAttributeSet, pDefStyAttribute, pDefStyRes);
        initialise(context);
    }

    private void initialise(final Context pContext) {
        mGestureDetector = new GestureDetector(pContext, new GestureDetector.SimpleOnGestureListener(){
            @Override
            public boolean onDown(MotionEvent e) {
                return true;
            }
            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                final int position = Gestures.this.pointToPosition
                        (Math.round(e1.getX()), Math.round(e1.getY()));

                if (Math.abs(e1.getY() - e2.getY()) > maxSwipeOffPath) {
                    if (Math.abs(e1.getX() - e2.getX()) > maxSwipeOffPath
                            || Math.abs(velocityY) < thresholdVelocity) {
                        return false;
                    }
                    if (e1.getY() - e2.getY() > minSwipeDistance) {
                        LocallySavedPuzzleActivity.moveTiles(pContext, LocallySavedPuzzleActivity.up, position);
                    } else if (e2.getY() - e1.getY() > minSwipeDistance) {
                        LocallySavedPuzzleActivity.moveTiles(pContext, LocallySavedPuzzleActivity.down, position);
                    }
                } else {
                    if (Math.abs(velocityX) < thresholdVelocity) {
                        return false;
                    }
                    if (e1.getX() - e2.getX() > minSwipeDistance) {
                        LocallySavedPuzzleActivity.moveTiles(pContext, LocallySavedPuzzleActivity.left, position);
                    } else if (e2.getX() - e1.getX() > minSwipeDistance) {
                        LocallySavedPuzzleActivity.moveTiles(pContext, LocallySavedPuzzleActivity.right, position);
                    }
                }
                return super.onFling(e1, e2, velocityX, velocityY);
            }
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                float x = e.getX();
                float y = e.getY();
                final int position = Gestures.this.pointToPosition
                        (Math.round(e.getX()), Math.round(e.getY()));
                LocallySavedPuzzleActivity.flipTile(pContext, position);
                return true;
            }
        });
    }
    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        int action = ev.getActionMasked();
        mGestureDetector.onTouchEvent(ev);

        if (action == MotionEvent.ACTION_CANCEL || action == MotionEvent.ACTION_UP) {
            mFling = false;
        } else if (action == MotionEvent.ACTION_DOWN) {
            mTouchX = ev.getX();
            mTouchY = ev.getY();
        } else {
            if (mFling) {
                return true;
            }

            float dX = (Math.abs(ev.getX() - mTouchX));
            float dY = (Math.abs(ev.getY() - mTouchY));
            if ((dX > minSwipeDistance) || (dY > minSwipeDistance)) {
                mFling = true;
                return true;
            }
        }
        return super.onInterceptTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        return mGestureDetector.onTouchEvent(ev);
    }
}
