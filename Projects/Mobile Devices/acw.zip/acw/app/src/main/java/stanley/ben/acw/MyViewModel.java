package stanley.ben.acw;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.ArrayList;

public class MyViewModel extends AndroidViewModel {
    private LiveData<ArrayList<Puzzle>> mPuzzle;
    private LiveData<Puzzle> mSelectedPuzzle;
    private Repository mRepository;
    private int mSelectedIndex;

    public MyViewModel(@NonNull Application pApplication){
        super(pApplication);
        //getItems();
        mRepository = Repository.getInstance(getApplication());
    }

    public LiveData<ArrayList<Puzzle>> getItems() {
        if(mPuzzle == null){
            mPuzzle = mRepository.getItems();
            //generateItems();
            //selectItem(0);
        }
        return mPuzzle;
    }

    public LiveData<Puzzle> getItem(int pItemIndex) {
        return mRepository.getItem(pItemIndex);
    }

    public void selectItem(int pIndex) {
        if(pIndex != mSelectedIndex || mSelectedPuzzle == null){
            mSelectedIndex = pIndex;
            mSelectedPuzzle = getItem(mSelectedIndex);
        }
    }

    public LiveData<Puzzle> getSelectedItem() {
        return mSelectedPuzzle;
    }

}
