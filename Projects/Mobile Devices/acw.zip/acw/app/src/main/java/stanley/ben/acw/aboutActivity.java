package stanley.ben.acw;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class aboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        TextView heading = (TextView) findViewById(R.id.aboutHeading);
        heading.setText("Jumble - about\r\n");

        TextView text = (TextView) findViewById(R.id.aboutText);
        text.setText("Click 'Puzzles' to load in the JSON puzzle files and then select " +
                "a puzzle to play.\r\n\r\nClick 'High Scores' to see the previous high scores of solved puzzles.\r\n\r\nClick 'Play " +
                "Locally Saved Puzzle' to play a  locally saved working version of one of the 3 puzzles");
    }
}
