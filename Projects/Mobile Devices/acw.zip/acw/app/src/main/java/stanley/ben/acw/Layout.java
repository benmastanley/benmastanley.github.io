package stanley.ben.acw;

import android.graphics.Bitmap;

public class Layout {
    private int mRows;
    private int mColumns;
    // mDimensions contains size of grid

    // mStartLayout contains the number .png file
    private int[][] mStartLayout;// = new int[mRows][mColumns];
    // mRotated states if tile is rotated 180 degrees
    private boolean[][] mRotated; // = new boolean[mRows][mColumns];

    public Layout(int pRows, int pColumns,  int[][] pStartLayout, boolean[][] pRotated){ //Bitmap[] pImages,
        setRows(pRows);
        setColumns(pColumns);
        //setImages(pImages);
        setStartLayout(pStartLayout);
        setRotated(pRotated);
    }

    public int getRows() { return mRows; }
    public void setRows(int pRows) { mRows = pRows; }

    public int getColumns() { return mColumns; }
    public void setColumns(int pColumns) { mColumns = pColumns; }

    /*
    public Bitmap[] getImages() { return mImages; }
    public void setImages(Bitmap[] pImages) { mImages = pImages; }
    */

    public int[][] getStartLayout() { return mStartLayout; }
    public void setStartLayout(int[][] pStartLayout) { mStartLayout = pStartLayout; }

    public boolean[][] getRotated() { return mRotated; }
    public void setRotated(boolean[][] pRotated) { mRotated = pRotated; }


}
