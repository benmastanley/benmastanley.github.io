package stanley.ben.acw;

import androidx.annotation.Nullable;
import androidx.fragment.app.ListFragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.List;

public class MyListFragment extends ListFragment {

    MyViewModel mViewModel;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mViewModel = ViewModelProviders.of(getActivity()).get(MyViewModel.class);

        // Create the observer which updates the UI.
        final Observer<List<Puzzle>> itemObserver = new Observer<List<Puzzle>>() {
            @Override
            public void onChanged(@Nullable final List<Puzzle> items) {
                ItemAdapter itemAdapter = new ItemAdapter(getActivity(), mViewModel.getItems().getValue());
                setListAdapter(itemAdapter);
            }
        };

        // Observe the LiveData, passing in this activity as the LifecycleOwner and teh observer.
        mViewModel.getItems().observe(this, itemObserver);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        mViewModel.selectItem(position);
        showContent(position);
    }

    public void showContent(int index){
        Intent intent = new Intent();

        intent.setClass(getActivity(), ItemActivity.class);

        intent.putExtra("index", index);

        startActivity(intent);
    }
}
