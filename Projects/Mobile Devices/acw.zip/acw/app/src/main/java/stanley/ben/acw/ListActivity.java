package stanley.ben.acw;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ListActivity extends AppCompatActivity {

    //private int rows = 4;
    //private int columns = 3;
    //private int squares = (rows * columns);
    //private String [] tileList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        // TODO - Delete this as in mainActivity now instead
        // Repository.getInstance(getApplicationContext()).loadFromJsonIndex();
        //LiveData<ArrayList<String>> s  = Repository.getInstance(getApplicationContext()).loadFromJsonIndex();

        //setup();
    }

    /*private void setup() {
        tileList = new String[squares];
        for(int i=0; i<squares; i++) {
            tileList[i] = String.valueOf(i);
        }
    }*/
}
