package stanley.ben.acw;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;

import java.util.ArrayList;

public class SPCustomAdapter extends BaseAdapter {
    private ArrayList<Button> mButtons = null;
    private int mColumnWidth, mColumnHeight;

    public SPCustomAdapter(ArrayList<Button> pButtons,
                           int pColumnWidth,
                           int pColumnHeight)
    {
        mButtons = pButtons;
        mColumnWidth = pColumnWidth;
        mColumnHeight = pColumnHeight;
    }

    @Override
    public int getCount() {
        return mButtons.size();
    }

    @Override
    public Object getItem(int pPosition) {
        return (Object) mButtons.get(pPosition);
    }

    @Override
    public long getItemId(int pPosition) {
        return pPosition;
    }

    @Override
    public View getView(int pPosition, View pConvertView, ViewGroup pParent) {
        Button button;
        if(pConvertView==null){
            button = mButtons.get(pPosition);
        }
        else{
            button = (Button) pConvertView;
        }
        android.widget.AbsListView.LayoutParams parameters =
                new android.widget.AbsListView.LayoutParams(mColumnWidth, mColumnHeight);
        button.setLayoutParams(parameters);

        return button;
    }
}
