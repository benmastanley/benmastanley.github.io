package stanley.ben.acw;

import android.content.Context;
import android.graphics.Bitmap;
import android.widget.ImageView;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Repository {

    private static Repository sRepository;
    private Context mApplicationContext;

    MutableLiveData<ArrayList<Puzzle>> mutablePuzzlesIndex;
    //private LiveData<ArrayList<Item>> mItems;
    //private LiveData<Item> mSelectedItem;
    //private LiveData<ArrayList<String>> mItems;
    //private LiveData<String> mSelectedItem;

    private LiveData<ArrayList<Puzzle>> mPuzzles;
    private LiveData<Puzzle> mSelectedPuzzle;

    private Repository(Context pApplicationContext) {
        this.mApplicationContext = pApplicationContext;
    }

    public static Repository getInstance(Context pApplicationContext) {
        if (sRepository == null) {
            sRepository = new Repository(pApplicationContext);
        }
        return  sRepository;
    }


    public LiveData<ArrayList<Puzzle>> loadItemsFromJSONIndex() {
        RequestQueue queue = Volley.newRequestQueue(mApplicationContext);
        String url = "https://www.goparker.com/600096/jumble/index.json";
        mutablePuzzlesIndex = new MutableLiveData<>();
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        ArrayList<Puzzle> puzzlesIndex = parseJSONIndexResponse(response);
                        mutablePuzzlesIndex.setValue(puzzlesIndex);
                        mPuzzles = mutablePuzzlesIndex;
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String errorResponse = "That didn't work!";
                    }
                });
        queue.add(jsonObjectRequest);
        return mutablePuzzlesIndex; // TODO change this
    }


    private ArrayList<Puzzle> parseJSONIndexResponse(JSONObject pResponse) {
        ArrayList<String> items = new ArrayList<>();
        ArrayList<Puzzle> puzzles = new ArrayList<>();
        try {
            JSONArray itemsArray = pResponse.getJSONArray("PuzzleIndex");
            for (int i=0; i<itemsArray.length(); i++){
                String item = itemsArray.getString(i);
                items.add(item);

                /*ArrayList<Puzzle> puzzleTemp = loadJSONPuzzle(item);
                for(int x = 0; x < puzzleTemp.size(); x++) {
                    Puzzle tempX = puzzleTemp.get(x);
                    puzzle.add(tempX);
                }*/
            }
        }
        catch (JSONException e){
            e.printStackTrace();
        }
        for(int x=0; x<items.size(); x++)
        {
            String item = items.get(x);
            String url = "https://goparker.com/600096/jumble/puzzles/" + item;
            RequestQueue queue = Volley.newRequestQueue(mApplicationContext);

            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                    Request.Method.GET,
                    url,
                    null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            puzzles.add(parseJSONPuzzleResponse(response));
                            mutablePuzzlesIndex.setValue(puzzles);
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            String errorResponse = "That didn't work!";
                        }
                    });
            queue.add(jsonObjectRequest);
        }
        return puzzles;
    }

    /*
    private ArrayList<Puzzle> loadJSONPuzzle(String pItem) {
        //private ArrayList<Puzzle> loadJSONPuzzle(String pItem) {

            RequestQueue queue = Volley.newRequestQueue(mApplicationContext);
        String url = "https://goparker.com/600096/jumble/puzzles/" + pItem;

        //Puzzle puzzle = null;
        ArrayList<Puzzle> mutableItems = new ArrayList<>();
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Puzzle puzzle = parseJSONPuzzleResponse(response);
                        //mPuzzles.add(puzzle);
                        mutableItems.add(puzzle);
                        //mItems = mutableItems;
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String errorResponse = "That didn't work!";
                    }
                });
        queue.add(jsonObjectRequest);
        return mutableItems; // TODO change this
    }*/

    private Puzzle parseJSONPuzzleResponse(JSONObject pResponse) {
        Puzzle puzzle = null;

        try {
            String name = pResponse.getString("name");
            JSONArray imagesArray = pResponse.getJSONArray("PictureSet");
            String image1 = imagesArray.getString(0);
            String image2 = imagesArray.getString(1);
            String layoutString = pResponse.getString("layout");

            Layout layout = loadJSONLayout(layoutString);
            puzzle = new Puzzle(name, image1, image2, layout);

            //TODO - change bitmap[] images from layout to puzzle
            //Bitmap[] images = new Bitmap[24];

            String loadImage = image1;

            for(int i=1; i<25; i++) //parse image sections
            {
                int intNumber = i;
                if(i > 12) {
                    loadImage = image2;
                    intNumber = intNumber - 12;
                }
                String number = Integer.toString(intNumber);
                String imgUrl = "https://goparker.com/600096/jumble/images/"+
                        loadImage + "/" + number + ".png";
                //images[i-1] = loadImage(imgUrl);
                //images[i-1] = null;
                int arrayIndex = i-1;

                loadImage(imgUrl, puzzle, arrayIndex);
            }
        }
        catch (JSONException e){
            e.printStackTrace();
        }
        return puzzle;
    }
    public void loadImage(String pUrl, Puzzle pPuzzle, int pIndex)
    {
        RequestQueue queue = Volley.newRequestQueue(mApplicationContext);
        ImageRequest imageRequest = new ImageRequest(
                pUrl, new Response.Listener<Bitmap>() {
            @Override
            public void onResponse(Bitmap response) {
                pPuzzle.setBitmap(response, pIndex);
            }
        },
                0, 0,
                ImageView.ScaleType.CENTER_CROP,
                Bitmap.Config.RGB_565,
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String errorResponse = "That didn't work!";
                    }
                });
        queue.add(imageRequest);
    }

    private Layout loadJSONLayout(String pLayoutString){
        Layout mLayout = null;
        RequestQueue queue = Volley.newRequestQueue(mApplicationContext);
        String url = "https://www.goparker.com/600096/jumble/layouts/" + pLayoutString;

        final MutableLiveData<Layout> mutableItems = new MutableLiveData<>();
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Layout layout = parseJSONLayoutResponse(response);
                        mutableItems.setValue(layout);
                        //mItems = mutableItems;
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String errorResponse = "That didn't work!";
                    }
                });
        queue.add(jsonObjectRequest);
        mLayout = mutableItems.getValue();
        return mLayout;
    }

    private Layout parseJSONLayoutResponse(JSONObject pResponse){
        Layout layout = null;
        int rows = 4;
        int columns = 3;
        try{
            rows = pResponse.getInt("rows");
            columns = pResponse.getInt("columns");
            //TODO remove bitmap images from layout and its constructor/class
            //Bitmap[] images = new Bitmap[24];
            int[][] startLayout = new int[rows][columns];
            boolean[][] rotated = new boolean[rows][columns];
            JSONArray layoutArray = pResponse.getJSONArray("layout");

            for(int i=0; i<rows; i++)
            {
                JSONArray tempArray = layoutArray.getJSONArray(i);
                for(int z=0; z<columns; z++)
                {
                    String tempString = tempArray.getString(z);
                    if(tempString.contains("r")){
                        rotated[i][z] = true;
                        tempString = tempString.substring(0, 1);
                    }
                    startLayout[i][z] = Integer.parseInt(tempString);
                }
            }

            layout = new Layout(rows, columns,  startLayout, rotated); // images,
        }
        catch (JSONException e){
            e.printStackTrace();
        }
        return layout;
    }

    public LiveData<ArrayList<Puzzle>> getItems() {
        if(mPuzzles == null) {
            mPuzzles= loadItemsFromJSONIndex();
        }
        return mPuzzles;
    }
    public LiveData<Puzzle> getItem(final int pItemIndex) {
        LiveData<Puzzle> transformedItem = Transformations.switchMap(
                mPuzzles,
                items -> {
            MutableLiveData<Puzzle> itemData = new MutableLiveData<Puzzle>();
            Puzzle item = items.get(pItemIndex);
            itemData.setValue(item);

            return itemData;
        });
        mSelectedPuzzle = transformedItem;
        return mSelectedPuzzle;
    }
}
