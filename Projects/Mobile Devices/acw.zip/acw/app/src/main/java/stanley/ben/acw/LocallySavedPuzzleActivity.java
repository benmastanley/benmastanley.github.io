package stanley.ben.acw;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class LocallySavedPuzzleActivity extends AppCompatActivity {

    private static final int rows = 4;
    private static final int columns = 3;
    private static int numOfTiles = rows * columns;
    private static String[] tiles;
    private static String[] sides; // string value of "Front" or "Back"
    private static Gestures mGridView;
    private static int mColumnWidth, mColumnHeight;

    public static final String up = "up";
    public static final String down = "down";
    public static final String left = "left";
    public static final String right = "right";

    private static int mMoves = 0;
    private static int secondsPassed = 0;
    private static int completionTime;
    private static int mCompletedMoves;
    private static String puzzleName;
    public static ArrayList<Button> buttons;

    Timer myTimer = new Timer();
    TimerTask task = new TimerTask() {
        @Override
        public void run() {
            secondsPassed++;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_locally_saved_puzzle);
        Bundle bundle = getIntent().getExtras();
        puzzleName = bundle.getString("puzzleName");

        loadBoard();
        setStartLayout();
        setDimensions();
        myTimer.scheduleAtFixedRate(task, 0, 1000);
    }

    @Override
    protected void onResume() {
        Context pContext = this.getApplicationContext();
        displayLayout(pContext);
        super.onResume();
    }

    private void setDimensions() {
        ViewTreeObserver viewTreeObserver = mGridView.getViewTreeObserver();
        viewTreeObserver.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                mGridView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                int width = mGridView.getMeasuredWidth();
                int height = mGridView.getMeasuredHeight();
                int statusBarHeight = retrieveStatusBarHeight(getApplicationContext());
                int reqHeight = height - statusBarHeight;
                mColumnWidth = width / columns;
                mColumnHeight = reqHeight / rows;

                displayLayout(getApplicationContext());
            }
        });
    }

    private int retrieveStatusBarHeight(Context context){
        int result = 0;
        int resID = context.getResources().getIdentifier("status_bar_height", "dimen", "android");

        if(resID > 0) {
            result = context.getResources().getDimensionPixelOffset(resID);
        }
        return result;
    }

    private static void displayLayout(Context pContext) {
        buttons = new ArrayList<>();
        Button button;
        String side;
        switch(puzzleName) {
            case "Necking":
                for (int i = 0; i < tiles.length; i++) {
                    side = sides[i];
                    button = new Button(pContext);
                    switch (tiles[i]) { //switch statement to determine which image
                        case "0":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.giraffe1_1);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.giraffe2_1);
                            }
                            break;
                        case "1":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.giraffe1_2);
                            }
                            else{
                                button.setBackgroundResource(R.drawable.giraffe2_2);
                            }
                            break;
                        case "2":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.giraffe1_3);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.giraffe2_3);
                            }
                            break;
                        case "3":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.giraffe1_4);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.giraffe2_4);
                            }
                            break;
                        case "4":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.giraffe1_5);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.giraffe2_5);
                            }
                            break;
                        case "5":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.giraffe1_6);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.giraffe2_6);
                            }
                            break;
                        case "6":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.giraffe1_7);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.giraffe2_7);
                            }
                            break;
                        case "7":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.giraffe1_8);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.giraffe2_8);
                            }
                            break;
                        case "8":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.giraffe1_9);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.giraffe2_9);

                            }
                            break;
                        case "9":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.giraffe1_10);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.giraffe2_10);
                            }
                            break;
                        case "10":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.giraffe1_11);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.giraffe2_11);
                            }
                            break;
                        case "11":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.giraffe1_12);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.giraffe2_12);
                            }
                            break;
                    }
                    buttons.add(button);
                }
                break;
            case "Tractor":
                for (int i = 0; i < tiles.length; i++) {
                    side = sides[i];
                    button = new Button(pContext);
                    switch (tiles[i]) { //switch statement to determine which image
                        case "0":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.tractor1_1);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.tractor2_1);
                            }
                            break;
                        case "1":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.tractor1_2);
                            }
                            else{
                                button.setBackgroundResource(R.drawable.tractor2_2);
                            }
                            break;
                        case "2":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.tractor1_3);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.tractor2_3);
                            }
                            break;
                        case "3":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.tractor1_4);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.tractor2_4);
                            }
                            break;
                        case "4":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.tractor1_5);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.tractor2_5);
                            }
                            break;
                        case "5":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.tractor1_6);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.tractor2_6);
                            }
                            break;
                        case "6":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.tractor1_7);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.tractor2_7);
                            }
                            break;
                        case "7":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.tractor1_8);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.tractor2_8);
                            }
                            break;
                        case "8":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.tractor1_9);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.tractor2_9);

                            }
                            break;
                        case "9":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.tractor1_10);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.tractor2_10);
                            }
                            break;
                        case "10":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.tractor1_11);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.tractor2_11);
                            }
                            break;
                        case "11":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.tractor1_12);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.tractor2_12);
                            }
                            break;
                    }
                    buttons.add(button);
                }
                break;
            case "Piping":
                for (int i = 0; i < tiles.length; i++)
                {
                    side = sides[i];
                    button = new Button(pContext);
                    switch (tiles[i]) { //switch statement to determine which image
                        case "0":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.pipes1_1);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.pipes2_1);
                            }
                            break;
                        case "1":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.pipes1_2);
                            }
                            else{
                                button.setBackgroundResource(R.drawable.pipes2_2);
                            }
                            break;
                        case "2":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.pipes1_3);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.pipes2_3);
                            }
                            break;
                        case "3":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.pipes1_4);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.pipes2_4);
                            }
                            break;
                        case "4":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.pipes1_5);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.pipes2_5);
                            }
                            break;
                        case "5":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.pipes1_6);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.pipes2_6);
                            }
                            break;
                        case "6":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.pipes1_7);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.pipes2_7);
                            }
                            break;
                        case "7":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.pipes1_8);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.pipes2_8);
                            }
                            break;
                        case "8":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.pipes1_9);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.pipes2_9);

                            }
                            break;
                        case "9":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.pipes1_10);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.pipes2_10);
                            }
                            break;
                        case "10":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.pipes1_11);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.pipes2_11);
                            }
                            break;
                        case "11":
                            if(side == "Front") {
                                button.setBackgroundResource(R.drawable.pipes1_12);
                            }
                            else {
                                button.setBackgroundResource(R.drawable.pipes2_12);
                            }
                            break;
                    }
                    buttons.add(button);
                }
                break;
        }
        mGridView.setAdapter(new SPCustomAdapter(buttons, mColumnWidth, mColumnHeight));
    }

    private void setStartLayout() {
        // TODO - arrange the files according to the layout.json file
        int index;
        String temp;
        Random r = new Random();

        for(int i = tiles.length - 1; i>0; i--) {
            index = r.nextInt(i+1);
            temp= tiles[index];
            tiles[index] = tiles[i];
            tiles[i] = temp;
        }
    }

    private void loadBoard() {
        mGridView = (Gestures) findViewById(R.id.grid);
        mGridView.setNumColumns(columns);

        tiles = new String[numOfTiles];
        sides = new String[numOfTiles];

        for(int i=0; i<numOfTiles; i++){
            tiles[i] = String.valueOf(i);
            sides[i] = "Front"; // This needs to change if initial layout with mixed sides is implemented.
        }
    }
    private static void swap(Context pContext, int pPosition, int pSwap) {
        String newPos = tiles[pPosition+pSwap];
        String newSide = sides[pPosition+pSwap];

        tiles[pPosition+pSwap] = tiles[pPosition];
        sides[pPosition+pSwap] = sides[pPosition];

        tiles[pPosition] = newPos;
        sides[pPosition] = newSide;

        displayLayout(pContext);
        mMoves++;
        if(puzzleSolved()){
            completionTime = secondsPassed;
            Toast.makeText(pContext,"Puzzle Completed in " + mMoves + " moves, and " +
                    completionTime + " seconds!!!", Toast.LENGTH_LONG).show();
        }
    }

    private static boolean puzzleSolved() {
        boolean isSolved = false;
        for(int i =0; i<tiles.length; i++) { // Check to see if Front image is completed
            if(tiles[i].equals(String.valueOf(i)) & sides[i].equals("Front")){
                isSolved = true;
            }
            else {
                isSolved = false;
                break;
            }
        }
        if(isSolved) {
            return isSolved;
        }
        for(int i =0; i<tiles.length; i++) { // Check to see if Back image is completed
            if(tiles[i].equals(String.valueOf(i)) & sides[i].equals("Back")){
                isSolved = true;
            }
            else {
                isSolved = false;
                break;
            }
        }
        mCompletedMoves = mMoves;
        return isSolved;
    }

    public static void moveTiles(Context pContext, String pDirection, int pPosition){
        switch(pPosition){
            case 0:
                switch(pDirection){
                    case right: swap(pContext, pPosition, 1); break;
                    case down: swap(pContext, pPosition, 3); break;
                    default: Toast.makeText(pContext, "Invalid move", Toast.LENGTH_SHORT).show();
                }
                break;
            case 1:
                switch(pDirection){
                    case left: swap(pContext, pPosition, -1); break;
                    case right: swap(pContext, pPosition, 1); break;
                    case down: swap(pContext, pPosition, 3); break;
                    default: Toast.makeText(pContext, "Invalid move", Toast.LENGTH_SHORT).show();
                }
                break;
            case 2:
                switch(pDirection){
                    case left: swap(pContext, pPosition, -1); break;
                    case down: swap(pContext, pPosition, 3); break;
                    default: Toast.makeText(pContext, "Invalid move", Toast.LENGTH_SHORT).show();
                }
                break;
            case 3:
            case 6:
                switch(pDirection){
                    case up: swap(pContext, pPosition, -3); break;
                    case right: swap(pContext, pPosition, 1); break;
                    case down: swap(pContext, pPosition, 3); break;
                    default: Toast.makeText(pContext, "Invalid move", Toast.LENGTH_SHORT).show();
                }
                break;
            case 4:
            case 7:
                switch(pDirection){
                    case up: swap(pContext, pPosition, -3); break;
                    case left: swap(pContext, pPosition, -1); break;
                    case right: swap(pContext, pPosition, 1); break;
                    case down: swap(pContext, pPosition, 3); break;
                    default: Toast.makeText(pContext, "Invalid move", Toast.LENGTH_SHORT).show();
                }
                break;
            case 5:
            case 8:
                switch(pDirection){
                    case up: swap(pContext, pPosition, -3); break;
                    case left: swap(pContext, pPosition, -1); break;
                    case down: swap(pContext, pPosition, 3); break;
                    default: Toast.makeText(pContext, "Invalid move", Toast.LENGTH_SHORT).show();
                }
                break;

            case 9:
                switch(pDirection){
                    case up: swap(pContext, pPosition, -3); break;
                    case right: swap(pContext, pPosition, 1); break;
                    default: Toast.makeText(pContext, "Invalid move", Toast.LENGTH_SHORT).show();
                }
                break;

            case 10:
                switch(pDirection){
                    case up: swap(pContext, pPosition, -3); break;
                    case left: swap(pContext, pPosition, -1); break;
                    case right: swap(pContext, pPosition, 1); break;
                    default: Toast.makeText(pContext, "Invalid move", Toast.LENGTH_SHORT).show();
                }
                break;

            case 11:
                switch(pDirection){
                    case up: swap(pContext, pPosition, -3); break;
                    case left: swap(pContext, pPosition, -1); break;
                    default: Toast.makeText(pContext, "Invalid move", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }
    public static void flipTile(Context pContext, int pPosition){
        String side = sides[pPosition];
        if(side == "Front") sides[pPosition] = "Back";
        if(side == "Back") sides[pPosition] = "Front";
        displayLayout(pContext);
        mMoves++;
        if(puzzleSolved()){
            completionTime = secondsPassed;
            Toast.makeText(pContext,"Puzzle Completed in " + mMoves + " moves, and " +
                    completionTime + " seconds!!!", Toast.LENGTH_LONG).show();
        }
    }

    public static void rotateTile(Context pContext, int pPosition){
        // TODO - code rotating an image 180 degrees.
    }
}